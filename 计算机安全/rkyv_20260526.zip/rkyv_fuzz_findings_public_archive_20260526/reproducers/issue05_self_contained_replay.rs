// Self-contained minimal Issue 05 replay.
//
// The 64-byte minimized seed is embedded below, so this example does not need
// an external artifact file. It keeps only the payload construction and
// mutation stages needed to derive the malformed archived HashMap, then uses
// checked access before exercising the HashMap traversal path.

use std::collections::{BTreeMap, HashMap};

use rkyv::{
    api::{self, high},
    from_bytes,
    rancor::Error,
    util::AlignedVec,
    Archive, Deserialize, Serialize,
};

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
pub struct MapPayload {
    pub btree: BTreeMap<i32, i32>,
    pub hmap: HashMap<u64, i32>,
    pub nested: BTreeMap<i32, Vec<u8>>,
    pub tag: String,
    pub nonce: u64,
}

fn take_u8(data: &[u8], idx: &mut usize) -> u8 {
    if data.is_empty() {
        return 0;
    }
    let b = data[*idx % data.len()];
    *idx = idx.wrapping_add(1);
    b
}

fn take_u32(data: &[u8], idx: &mut usize) -> u32 {
    let b0 = take_u8(data, idx) as u32;
    let b1 = take_u8(data, idx) as u32;
    let b2 = take_u8(data, idx) as u32;
    let b3 = take_u8(data, idx) as u32;
    b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
}

fn take_u64(data: &[u8], idx: &mut usize) -> u64 {
    let lo = take_u32(data, idx) as u64;
    let hi = take_u32(data, idx) as u64;
    lo | (hi << 32)
}

fn take_i32(data: &[u8], idx: &mut usize) -> i32 {
    take_u32(data, idx) as i32
}

fn make_ascii(data: &[u8], idx: &mut usize, max_len: usize) -> String {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = String::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        let b = take_u8(data, idx);
        out.push((b'a' + (b % 26)) as char);
        i += 1;
    }
    out
}

fn build_payload(data: &[u8]) -> MapPayload {
    let mut idx = 0usize;

    let mut btree = BTreeMap::new();
    let btree_len = (take_u8(data, &mut idx) as usize) % 80;
    let mut i = 0usize;
    while i < btree_len {
        btree.insert(take_i32(data, &mut idx), take_i32(data, &mut idx));
        i += 1;
    }

    let mut hmap = HashMap::new();
    let hmap_len = (take_u8(data, &mut idx) as usize) % 80;
    let mut j = 0usize;
    while j < hmap_len {
        hmap.insert(take_u64(data, &mut idx), take_i32(data, &mut idx));
        j += 1;
    }

    let mut nested = BTreeMap::new();
    let nested_len = (take_u8(data, &mut idx) as usize) % 40;
    let mut k = 0usize;
    while k < nested_len {
        let key = take_i32(data, &mut idx);
        let blob_len = (take_u8(data, &mut idx) as usize) % 96;
        let mut blob = Vec::with_capacity(blob_len);
        let mut x = 0usize;
        while x < blob_len {
            blob.push(take_u8(data, &mut idx));
            x += 1;
        }
        nested.insert(key, blob);
        k += 1;
    }

    MapPayload {
        btree,
        hmap,
        nested,
        tag: make_ascii(data, &mut idx, 64),
        nonce: take_u64(data, &mut idx),
    }
}

fn mutate_inplace(buf: &mut [u8], data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 96;
    let mut i = 0usize;
    while i < rounds {
        let op = take_u8(data, &mut idx) % 4;
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match op {
            0 => {
                buf[p] ^= take_u8(data, &mut idx);
            }
            1 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    let bytes = take_u32(data, &mut idx).to_le_bytes();
                    buf[p..p + 4].copy_from_slice(&bytes);
                }
            }
            2 => {
                let s = (take_u32(data, &mut idx) as usize) % buf.len();
                buf[p] = buf[s];
            }
            _ => {
                let e = (p + ((take_u8(data, &mut idx) as usize) % 24))
                    .min(buf.len());
                if e > p + 1 {
                    buf[p..e].rotate_left(1);
                }
            }
        }
        i += 1;
    }
}

fn mutate_varlen(buf: &mut Vec<u8>, data: &[u8]) {
    if data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 80;
    let mut i = 0usize;
    while i < rounds {
        let op = take_u8(data, &mut idx) % 5;
        match op {
            0 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[p] ^= take_u8(data, &mut idx);
                }
            }
            1 => {
                if buf.len() < 32768 {
                    let p =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.insert(p, take_u8(data, &mut idx));
                }
            }
            2 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf.remove(p);
                }
            }
            3 => {
                if !buf.is_empty() {
                    let n =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.truncate(n);
                }
            }
            _ => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    let e = (p + ((take_u8(data, &mut idx) as usize) % 32))
                        .min(buf.len());
                    if e > p + 1 {
                        buf[p..e].rotate_right(1);
                    }
                }
            }
        }
        i += 1;
    }
}

fn smash_words(buf: &mut Vec<u8>, data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }

    let words32 = [
        0u32,
        1,
        2,
        4,
        8,
        16,
        32,
        0x7fff_ffff,
        0x8000_0000,
        0xffff_ffff,
    ];
    let words64 = [
        0u64,
        1,
        2,
        4,
        8,
        16,
        32,
        buf.len() as u64,
        api::root_position::<ArchivedMapPayload>(buf.len()) as u64,
        u32::MAX as u64,
        u64::MAX,
    ];

    let mut idx = 0usize;
    let rounds = 8 + ((take_u8(data, &mut idx) as usize) % 48);
    let mut i = 0usize;
    while i < rounds {
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match take_u8(data, &mut idx) % 5 {
            0 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    let v = words32
                        [(take_u8(data, &mut idx) as usize) % words32.len()];
                    buf[p..p + 4].copy_from_slice(&v.to_le_bytes());
                }
            }
            1 => {
                if buf.len() >= 8 && p <= buf.len() - 8 {
                    let v = words64
                        [(take_u8(data, &mut idx) as usize) % words64.len()];
                    buf[p..p + 8].copy_from_slice(&v.to_le_bytes());
                }
            }
            2 => {
                let end = (p + 2 + ((take_u8(data, &mut idx) as usize) % 14))
                    .min(buf.len());
                if end > p {
                    buf[p..end].fill(0xff);
                }
            }
            3 => {
                if !buf.is_empty() {
                    let src = (take_u32(data, &mut idx) as usize) % buf.len();
                    let width = 1 + ((take_u8(data, &mut idx) as usize) % 8);
                    if src + width <= buf.len() && p + width <= buf.len() {
                        let tmp = buf[src..src + width].to_vec();
                        buf[p..p + width].copy_from_slice(&tmp);
                    }
                }
            }
            _ => {
                if buf.len() >= 4 {
                    let q = (p & !3).min(buf.len() - 4);
                    let rel = buf.len().wrapping_sub(q) as u32;
                    buf[q..q + 4].copy_from_slice(&rel.to_le_bytes());
                }
            }
        }
        i += 1;
    }
}

fn exhaust_payload(p: &ArchivedMapPayload, salt: usize) {
    let _ = p.tag.len();
    let _ = p.nonce;

    let mut seen = 0usize;
    for (k, v) in p.btree.iter() {
        let _ = k;
        let _ = v;
        if ((seen ^ salt) & 3) == 0 {
            let _ = p.btree.get(k);
            let _ = p.btree.contains_key(k);
        }
        seen += 1;
        if seen > 4096 {
            break;
        }
    }

    let mut ranged = 0usize;
    for (k, v) in p.btree.range(..) {
        let _ = k;
        let _ = v;
        ranged += 1;
        if ranged > 4096 {
            break;
        }
    }

    for k in p.btree.keys().take(256) {
        let _ = k;
    }
    for v in p.btree.values().take(256) {
        let _ = v;
    }

    let _ = p.hmap.len();
    let _ = p.hmap.capacity();

    let mut hseen = 0usize;
    for (k, v) in p.hmap.iter() {
        let _ = k;
        let _ = v;
        if ((hseen ^ salt) & 1) == 0 {
            let _ = p.hmap.get(k);
            let _ = p.hmap.contains_key(k);
        }
        hseen += 1;
        if hseen > 4096 {
            break;
        }
    }

    for k in p.hmap.keys().take(256) {
        let _ = p.hmap.get(k);
    }
    for v in p.hmap.values().take(256) {
        let _ = v;
    }

    let _ = p.nested.len();
    for (k, b) in p.nested.iter() {
        let _ = k;
        if !b.is_empty() {
            let _ = b[0];
        }
    }
}

fn run_paths(bytes: &[u8], salt: usize) {
    let mut aligned: AlignedVec<16> = AlignedVec::new();
    aligned.extend_from_slice(bytes);

    let root_pos = api::root_position::<ArchivedMapPayload>(aligned.len());

    let mut valid = false;
    if root_pos < aligned.len() {
        if let Ok(p) =
            high::access_pos::<ArchivedMapPayload, Error>(&aligned, root_pos)
        {
            valid = true;
            exhaust_payload(p, salt);
        }
    }

    if valid || ((salt & 0x3f) == 0 && aligned.len() <= 4096) {
        let _ = from_bytes::<MapPayload, Error>(&aligned);
    }

    // The minimal reproducer intentionally does not use unchecked APIs.

    // Sub-slice follow-up is not needed for the Issue 05 timeout.
}

const ISSUE05_SEED: &[u8] = &[
    0xf9, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x35, 0x35, 0x00,
    0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35,
    0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0xfe, 0x00, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfd,
    0xff, 0xff, 0xff, 0xff,
];

fn main() {
    let data = ISSUE05_SEED;

    run_paths(data, data.len());

    let payload = build_payload(data);
    let clean = match rkyv::to_bytes::<Error>(&payload) {
        Ok(v) => v.into_vec(),
        Err(_) => return,
    };

    run_paths(&clean, clean.len() ^ 0x7711);

    let mut semi = clean.clone();
    mutate_inplace(&mut semi, data);
    run_paths(&semi, data[0] as usize ^ 0x33aa);

    let mut mutated = clean;
    mutate_varlen(&mut mutated, data);
    run_paths(&mutated, data[0] as usize ^ 0xaa33);

    smash_words(&mut mutated, data);
    run_paths(&mutated, data[0] as usize ^ 0xcc55);
}
