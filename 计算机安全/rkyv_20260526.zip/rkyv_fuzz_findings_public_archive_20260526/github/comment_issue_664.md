Thanks, this looks like it overlaps with a local repro I had grouped under the
same SwissTable / `ArchivedHashTable` verifier family, so I am not opening a
duplicate issue.

The additional angle from my triage is verifier-side: the malformed
control-byte layout should be rejected earlier by checking that the counted
`FULL` buckets agree with the archived table header length, rather than
allowing later map access to reach the crash.

I have a minimized repro artifact, replay log, and patch sketch for this case
in my SwissTable-only follow-up bundle. If useful, I can attach the reduced
artifact or relevant patch hunk directly here.