Thanks, this looks like it overlaps with a local repro I had grouped under the
same SwissTable / `ArchivedHashTable` verifier family, so I am not opening a
duplicate issue.

The additional angle from my triage is verifier-side: the invalid empty-table
state should be rejected earlier by enforcing that `len == 0` implies
`cap == 0`, rather than allowing the safe path to reach `control_raw`.

I have a reproducer and a verifier-side patch sketch for this case in my
SwissTable-only follow-up bundle. If useful, I can attach the reduced artifact
or relevant patch hunk directly here.