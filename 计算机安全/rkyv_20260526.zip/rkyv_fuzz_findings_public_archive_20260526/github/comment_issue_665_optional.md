Optional supplementary note:

The same verifier-hardening patch I prepared for the malformed table-shape
family also adds a backing-pointer containment check before the backing layout
is used. I am treating that as adjacent overlap with this issue rather than as
a separate claim.

If useful, I can attach the relevant patch hunk directly here.