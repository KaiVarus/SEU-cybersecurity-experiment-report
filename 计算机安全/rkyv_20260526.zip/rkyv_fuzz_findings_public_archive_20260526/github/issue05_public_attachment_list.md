# Issue 05 public attachment list

If `Issue 05` is filed separately, attach the reduced seed and the final
confirmation logs directly to the GitHub issue.

## Core public attachments

- `artifacts/minimized/issue05_probe_cycle.min`
- `reproducers/issue05_self_contained_replay.rs`
- `scripts/run_issue05_self_contained.sh`
- `logs/issue05_self_contained_final.log`
- `logs/issue05_self_contained_script_runs.log`
- `reproducers/issue05_minimal_replay.rs`
- `scripts/run_issue05_minimal.sh`
- `logs/issue05_minimal_replay_final.log`
- `logs/issue05_minimal_script_runs.log`
- `logs/issue05_final_helper_20260512.log`
- `logs/issue05_final_direct_compare_20260512.log`
- `logs/issue05_final_trace_20260512.log`
- `logs/issue05_final_patched_minimized_20260512.log`

Only the self-contained/minimal replay logs and the `issue05_final_*` logs above
should be treated as the primary public evidence chain. Older exploratory logs
should not be used as public proof.

## Supporting files to cite or attach if needed

- `docs/ISSUE_05_ROOT_CAUSE.md`
- `artifacts/original/issue05_probe_cycle.timeout`
- `reproducers/swisstable_target9_replay.rs`
- `logs/issue05_minimization_20260512.log`
- `logs/issue05_repro_command_20260512.txt`
- `patches/02_swisstable_probe_cycle_hardening.patch`
- `templates/new_issue_05_probe_cycle.md`
