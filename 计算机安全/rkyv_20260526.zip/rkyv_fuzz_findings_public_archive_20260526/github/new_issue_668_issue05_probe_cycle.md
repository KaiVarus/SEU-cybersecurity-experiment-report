Title: SwissTable lookup can non-terminate after checked access on crafted HashMap (`0.8.16`)

### Summary

While re-testing SwissTable validation and probing behavior on the current
`0.8.16` source line, I found a crafted archived `HashMap` input that
consistently causes non-terminating lookup / traversal behavior after the
checked access path has already succeeded.

I am filing this separately because I could not find a clear current tracker
duplicate for this safe-path non-termination case. There is historical overlap
with the `0.8.1` release note, which says that release "corrects an infinite
loop in hash map probing":

- https://github.com/rkyv/rkyv/releases/tag/0.8.1

The most accurate framing seems to be:

- confirmed denial-of-service / non-termination via crafted input
- possible regression / reappearance / incomplete-fix candidate in the old
  SwissTable probing family
- not a memory-safety claim

### Affected line

- current source line: `rkyv 0.8.16`
- clean baseline used for confirmation: `4a841456f348b9c8115ba4d9fda70332af3d69c5`

### Public evidence package

I attached the reduced seed, self-contained reproducer, and replay logs here:

- [issue05_public_evidence.zip](https://github.com/user-attachments/files/27640040/issue05_public_evidence.zip)

The preferred reproducer in that archive is
`issue05_self_contained_replay.rs`. It embeds the `64-byte` minimized seed, so
it does not require a separate input file.

### Reproduction result

On the clean `0.8.16` baseline:

- self-contained replay: `5/5` exact `20s` timeouts
- seed-file direct replay after prebuild: `10/10` exact `20s` timeouts
- long retry: `60s` timeout

With my local probe-cycle hardening patch applied to the same baseline, the
same self-contained replay and the same minimized seed both returned
immediately in repeated reruns.

### Checked-path proof

A trace-instrumented replay shows `checked_access_ok` before the run enters the
later `HashMap` traversal / lookup path and times out. The key trace fragment
is:

```text
trace:checked_access_ok
trace:before_checked_exhaust
trace:before_hmap_iter
summary: exit=124 wall=20.00 timeout=yes
```

### Root-cause direction

The current local root-cause model is that the unpatched SwissTable lookup path
assumes probing will eventually reach an empty control byte. A malformed
archived control-byte layout can violate that termination assumption and allow
the probe sequence to cycle forever.

The hardening patch I tested addresses this family in two ways:

- runtime probe-cycle detection in lookup paths
- verifier-side rejection of malformed tables whose probe sequence does not
  terminate as expected

### Reproduction command

From a clean `rkyv` checkout, copy the self-contained reproducer into the
examples directory and build once:

```bash
cp /path/to/issue05_self_contained_replay.rs examples/issue05_self_contained_replay.rs
cargo build -q -p rkyv --example issue05_self_contained_replay --features bytecheck
```

Run the example directly:

```bash
timeout 20s target/debug/examples/issue05_self_contained_replay
```

Expected behavior on the clean baseline is timeout exit status `124`. With the
local probe-cycle hardening patch applied, the same command returns normally.

The attached evidence zip includes the reduced seed, the self-contained
reproducer, and the final confirmation logs. If useful, I can also attach the
relevant patch hunk directly here.
