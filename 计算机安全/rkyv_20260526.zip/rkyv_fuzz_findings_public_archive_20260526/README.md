# rkyv fuzz findings public archive (2026-05-26)

This archive is a consolidated, public-facing preservation package for an
individual fuzzing study of `rkyv` archived collection validation. It is meant
for saving, sharing, or uploading to a GitHub repository as supporting material.

It summarizes five issue families, representative crash/timeout artifacts,
harnesses, minimized repro inputs, standalone reproducers, key replay logs,
patch sketches, public GitHub filing text, and the final course reports.

## Current public status

| Local ID | Component | Short description | Public status |
| --- | --- | --- | --- |
| Issue 01 | SwissTable / `ArchivedHashTable` | invalid empty table: `len == 0 && cap > 0` | commented on GitHub `#667` as duplicate/overlap |
| Issue 02 | SwissTable / `ArchivedHashTable` | counted `FULL` buckets disagree with archived header `len` | commented on GitHub `#664` as overlap; `#665` optional context |
| Issue 03 | B-tree | reachable inner-node child edge validation gap | retained as overlap context after upstream B-tree fix |
| Issue 04 | B-tree | entry-count / empty-leaf consistency gap | retained as overlap context after upstream B-tree fix |
| Issue 05 | SwissTable / probing | checked-access non-terminating lookup/traversal | opened separately as GitHub `#668` |

## Important scope notes

- The main supported-version anchor is `rkyv 0.8.16` on baseline
  `4a841456f348b9c8115ba4d9fda70332af3d69c5`.
- `0.8.8` logs are retained only as historical public-tag corroboration.
- `0.7.x` material is intentionally excluded from the active security scope.
- This package does not include private email screenshots or private email
  templates. It includes only public-facing summaries and GitHub-ready text.
- Text logs and scripts have been sanitized to replace local absolute paths
  with `<repo>`, `<workspace>`, or `<home>`.

## Directory layout

```text
docs/          issue analyses, root-cause notes, public status summaries
github/        public GitHub comments / issue text
artifacts/     representative original and minimized crash/timeout inputs
harnesses/     fuzz targets used during the campaign
reproducers/   standalone and reduced repro sources
scripts/       replay helper scripts copied for archival context
logs/key/      selected replay, triage, patch, and Issue 05 confirmation logs
patches/       patch sketches and historical combined patch
reports/       final English and Chinese LaTeX reports and PDFs
SHA256SUMS     checksums for all files in the archive
```

## Recommended reading order

1. `docs/SUMMARY.md`
2. `docs/PUBLIC_FILING_STATUS.md` and `docs/PUBLIC_TRACKER_STATUS.md`
3. `docs/HARNESS_AND_REPLAY.md`
4. `docs/CRASH_ARTIFACT_MAP.md`
5. The individual issue files under `docs/`
6. `reports/report_en.pdf` for the full narrative report

## Reproduction note

The easiest public reproducer is Issue 05:

```bash
cp reproducers/issue05_self_contained_replay.rs <rkyv-checkout>/examples/
cd <rkyv-checkout>
cargo build -q -p rkyv --example issue05_self_contained_replay --features bytecheck
timeout 20s target/debug/examples/issue05_self_contained_replay
```

On the clean `0.8.16` baseline, the expected behavior is timeout exit status
`124`. With the local probe-cycle hardening patch applied, the same reproducer
returns normally.
