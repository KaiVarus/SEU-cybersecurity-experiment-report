# Issue 03: `ArchivedBTreeMap::verify` could admit an invalid required child

## Summary

`ArchivedBTreeMap::verify` was too weak for a reachable inner-node edge that
the iterator always follows. A malformed archive could survive checked access,
and later traversal would descend through an invalid child relationship and
blow up while reading downstream value fields.

## Important nuance

The correct verifier rule is not "all child pointers must be valid".

The serializer intentionally emits invalid child pointers for unused inner
slots. The actionable bug is narrower:

- `lesser_nodes[0]` must be valid for every reachable inner node because the
  iterator descends through it unconditionally
- any non-invalid child pointer must recursively validate
- unused child slots may remain invalid

## Original symptom

Representative artifact:

- `crash-84c670c6d8c0ffdcf42b6136831a469b0f7e3071`

Observed downstream crash site:

- `string/repr.rs:53`

Historical crash evidence in this bundle:

- `logs/artifact_triage_20260505_124032.log`
- `logs/artifact_triage_20260505_124153.log`

Patched replay log in this bundle:

- `logs/target10_string_repr_oob.log`

## Fix

In inner-node verification:

- reject invalid slot `0` in `lesser_nodes`
- recurse through every non-invalid child pointer
- do not reject unused invalid slots purely because they are invalid

## Current verification status

Rechecked on the current tree:

- the historical artifact now replays cleanly
- `cargo test -p rkyv --features bytecheck btree_map -- --nocapture` passes
- the safe-path chain is summarized in `docs/SAFE_PATH_EVIDENCE.md`

## Submit with

- `rkyv/src/collections/btree/map/mod.rs`
