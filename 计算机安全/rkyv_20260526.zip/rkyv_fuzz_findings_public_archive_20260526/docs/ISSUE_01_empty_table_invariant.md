# Issue 01: `ArchivedHashTable::verify` accepted `len == 0 && cap > 0`

## Summary

`ArchivedHashTable::verify` treated only `(len == 0 && cap == 0)` as the empty
table special case. A malformed archived table with `len == 0 && cap > 0`
could therefore continue through validation and later panic when table helpers
assumed a non-empty backing allocation existed.

## Why this is a library bug

The failing samples were not just unchecked garbage fed into
`access_unchecked`. The original repro path entered checked validation first
and then crashed in the table implementation.

## Original symptom

- panic in `swiss_table/table.rs`
- historical artifacts:
  - `crash-9217a13a36375558a8a7f4e6dce55c334efc1cd9`
  - `crash-7ee6b76cde99938b9ded635436592d9c1c3fa6c3`
  - `crash-9cd0bb4e6c4a9d07b1e034b0351a88a03a8c788b`
  - `crash-c6da4401fd511b09072e9ffe5a6cebb10531f7f1`

Historical crash evidence in this bundle:

- `logs/artifact_triage_20260505_124032.log`
- `logs/artifact_triage_20260505_124153.log`

Patched replay logs in this bundle:

- `logs/target9_table_assert.log`
- `logs/target10_table_assert_a.log`
- `logs/target10_table_assert_b.log`
- `logs/target10_table_assert_c.log`

## Fix

Reject `len == 0 && cap > 0` during verification instead of treating it as a
table that may continue into control-byte iteration.

## Current verification status

Rechecked on the current tree:

- the four historical artifacts now replay cleanly
- see the corresponding clean replay logs listed above

## Submit with

- `rkyv/src/collections/swiss_table/table.rs`
