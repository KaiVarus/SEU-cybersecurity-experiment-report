# Issue 05 root-cause note

## Short version

The unpatched SwissTable lookup path assumes that probing will eventually reach
an empty control byte. A malformed archived control-byte layout can violate that
termination assumption and allow the probing sequence to cycle forever.

## Causal chain

1. A crafted archived hash map passes the checked `high::access_pos` path.
2. Later `HashMap` traversal / lookup work runs inside `exhaust_payload`.
3. The unpatched lookup path keeps probing because the malformed control-byte
   layout prevents normal termination.
4. The process does not crash immediately; instead it spins until the outer
   timeout cuts it off.

## Why this is still a safe-path claim

The local claim is not based on unchecked-only entry points. The fresh trace log
shows `checked_access_ok` before the timeout, so the archive first passed a
checked validation/access path and only then reached the pathological lookup
behavior.

## Why the local patch supports this model

`patches/02_swisstable_probe_cycle_hardening.patch` adds two protections:

- runtime cycle detection in the probe / lookup path
- verifier-side rejection of non-terminating probe sequences

The same minimized seed times out reliably on the unpatched baseline and returns
immediately on the patched baseline, which is consistent with this root-cause
model.
