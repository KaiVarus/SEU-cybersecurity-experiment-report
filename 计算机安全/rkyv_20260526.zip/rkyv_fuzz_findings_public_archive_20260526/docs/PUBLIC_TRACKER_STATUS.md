# Public tracker status

| Local issue | Public tracker status | Action |
| --- | --- | --- |
| Issue 01 | Exact/near duplicate of `#667` | Duplicate comment posted |
| Issue 02 | Overlaps `#664`; `#665` is adjacent context | Overlap comment posted on `#664`; `#665` optional |
| Issue 03 | B-tree overlap after maintainer-confirmed report/fix | No separate current filing |
| Issue 04 | B-tree overlap with public entry-count validation work | No separate current filing |
| Issue 05 | No clear current duplicate for checked-path non-termination | Opened as `#668` |

The public tracker material is preserved under `github/`. This package does not
include private email screenshots or private disclosure templates.
