# Harnesses and replay material

## Harnesses

The `harnesses/` directory preserves the main fuzz targets used in the campaign:

- `fuzz_target_9.rs`: map-payload style target that exercised `ArchivedHashMap`
  and related traversal paths.
- `fuzz_target_10.rs`: broader frame-payload target that also reached B-tree,
  string, and vec downstream behavior.
- `fuzz_target_11_safe_from_bytes.rs` and `fuzz_target_12_safe_access_map.rs`:
  safe-path focused harnesses.
- `fuzz_target_13_unsafe_hash_focus.rs` and
  `fuzz_target_14_unsafe_hash_set_focus.rs`: later hash-focused exploration.

The final public claims do not rely on unchecked-only behavior. Unchecked or
unsafe follow-up paths in older harnesses are useful for exercising downstream
state, but the report distinguishes them from checked-path evidence.

## Standalone reproducers

The `reproducers/` directory contains the most useful reduced replay sources:

- `issue05_self_contained_replay.rs`: preferred public reproducer for Issue 05;
  embeds the 64-byte minimized seed.
- `issue05_minimal_replay.rs`: file-based minimal replay for Issue 05.
- `swisstable_target9_replay.rs`: target-9 shaped SwissTable replay helper.

## Scripts

The `scripts/` directory is preserved for archival context. These scripts were
copied from the local repro workspace and sanitized for absolute paths where
possible. They may still need to be placed back into a matching `rkyv` checkout
layout before direct execution.

For public reproduction, prefer the self-contained Issue 05 reproducer because
it has the fewest path dependencies.

## Logs

`logs/key/` contains selected logs only. Long exploratory fuzz logs are omitted
from this public archive to keep the package focused.
