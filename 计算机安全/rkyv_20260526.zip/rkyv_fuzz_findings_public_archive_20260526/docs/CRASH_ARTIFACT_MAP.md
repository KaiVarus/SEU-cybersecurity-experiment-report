# Crash and timeout artifact map

This file maps representative preserved artifacts to issue families. The raw
artifact filenames are kept because they are the stable identifiers produced by
libFuzzer or the later minimization pass.

## Issue 01: SwissTable empty-table invariant

Representative original artifacts:

- `artifacts/original/crash-9217a13a36375558a8a7f4e6dce55c334efc1cd9`
- `artifacts/original/crash-7ee6b76cde99938b9ded635436592d9c1c3fa6c3`
- `artifacts/original/crash-9cd0bb4e6c4a9d07b1e034b0351a88a03a8c788b`
- `artifacts/original/crash-c6da4401fd511b09072e9ffe5a6cebb10531f7f1`
- `artifacts/original/issue01_empty_table.crash`

Key logs:

- `logs/key/standalone_issue01_empty_table.log`
- `logs/key/target9_table_assert.log`

## Issue 02: SwissTable FULL-bucket count / malformed table shape

Representative original or reduced artifacts:

- `artifacts/original/crash-e85e798ae1edacce08707d3486d3d4d6c630d4b9`
- `artifacts/original/crash-9d9b177cb9c3dcbe025341f33a318005bb2b32e2`
- `artifacts/original/issue02_hmap_oob.crash`
- `artifacts/minimized/issue02_hmap_overflow.min`
- `artifacts/minimized/issue02_vec_ub.min`

Key logs:

- `logs/key/target9_hmap_oob.log`
- `logs/key/target10_vec_ub.log`
- `logs/key/version_replay_0.8.8_hmap.log`

## Issue 03: B-tree invalid required child

Representative original artifact:

- `artifacts/original/crash-84c670c6d8c0ffdcf42b6136831a469b0f7e3071`

Key logs:

- `logs/key/artifact_triage_20260505_124032.log`
- `logs/key/artifact_triage_20260505_124153.log`
- `logs/key/target10_string_repr_oob.log`

## Issue 04: B-tree entry-count / empty-leaf consistency

Representative original artifacts:

- `artifacts/original/crash-b7c833ec658eafbb0bdb60c55c6bd086d683b5c0`
- `artifacts/original/crash-08defd8a6e42be22bf0975017ef86d4fc05ef9e6`
- `artifacts/original/crash-7a3b0803a526036324044d9ab5c90d4eaa5c7323`

Key log:

- `logs/key/version_replay_0.8.8_btree.log`

## Issue 05: SwissTable non-terminating lookup / traversal

Representative artifacts:

- `artifacts/original/issue05_probe_cycle.timeout`
- `artifacts/minimized/issue05_probe_cycle.min`

Key logs:

- `logs/key/issue05_final_helper_20260512.log`
- `logs/key/issue05_final_direct_compare_20260512.log`
- `logs/key/issue05_final_trace_20260512.log`
- `logs/key/issue05_final_patched_minimized_20260512.log`
- `logs/key/issue05_self_contained_final.log`
- `logs/key/issue05_self_contained_script_runs.log`
