# Patch Coverage Notes

## `patches/01_swisstable_verify_invariants.patch`

This patch contains three verifier hardening changes:

1. reject invalid empty-table state
   - `len == 0 && cap > 0`
2. reject invalid backing-pointer resolution
   - containment hardening before using the backing layout
3. reject mismatched `FULL`-bucket counts
   - counted control bytes must agree with the archived table header length

## How the local claims map onto that patch

- first-class local claim:
  - empty-table invariant acceptance (`Issue 01`)
- first-class local claim:
  - `FULL`-bucket-count / table-shape mismatch (`Issue 02`)
- supplemental context only:
  - backing-pointer containment hardening

The backing-pointer containment change overlaps public issue `#665` and should
not be presented as a separate local claim from this bundle unless it is split
into its own dedicated writeup.

## `patches/02_swisstable_probe_cycle_hardening.patch`

This patch adds:

- probe-cycle detection in runtime lookup
- verifier-side rejection of non-terminating probe sequences
- self-contained regression coverage for the historical timeout family

In this bundle, it is kept as appendix support for `Issue 05`, not as a main
standalone claim.

## Apply order

Apply either:

- `patches/00_swisstable_combined.patch`

or, for split review:

1. `patches/01_swisstable_verify_invariants.patch`
2. `patches/02_swisstable_probe_cycle_hardening.patch`
