# Issue 02: `ArchivedHashTable::verify` did not enforce `FULL` bucket count

## Summary

Checked access could accept malformed archived SwissTable layouts whose
control-byte bitmap did not match the table header length. Downstream runtime
operations then trusted bad metadata and eventually blew up while reading map
entries or values.

## Why this is a library bug

The safe-path failure happened after checked access had already accepted the
payload. The observed string and vec crashes were downstream effects of a bad
table shape being treated as valid.

## Original symptom

Representative artifacts:

- `crash-e85e798ae1edacce08707d3486d3d4d6c630d4b9`
- `crash-9d9b177cb9c3dcbe025341f33a318005bb2b32e2`

Typical blast radius:

- `swiss_table/map.rs:115`
- `vec.rs:56`

Historical crash evidence in this bundle:

- `logs/artifact_triage_20260505_124032.log`
- `logs/artifact_triage_20260505_124153.log`

Patched replay logs in this bundle:

- `logs/target9_hmap_oob.log`
- `logs/target10_vec_ub.log`

## Fix

During verification:

- count valid in-range `FULL` control bytes
- reject the archive if `full_count != len`

## Current verification status

Rechecked on the current tree:

- both representative artifacts now replay cleanly
- the safe-path chain is summarized in `docs/SAFE_PATH_EVIDENCE.md`

## Submit with

- `rkyv/src/collections/swiss_table/table.rs`
