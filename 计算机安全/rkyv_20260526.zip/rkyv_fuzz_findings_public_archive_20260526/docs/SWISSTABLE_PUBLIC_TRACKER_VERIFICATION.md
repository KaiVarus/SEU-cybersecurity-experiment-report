# SwissTable Public Tracker Verification (2026-05-12)

## Final mapping

- `Issue 01` -> exact duplicate of `#667`
- `Issue 02` -> overlapping duplicate of `#664`
- `Issue 02` has adjacent patch overlap with `#665`, but is not being split
  into a separate local claim
- `Issue 05` now satisfies the strong stability threshold on the current
  `0.8.16` line and has no clear current public tracker duplicate; historical
  overlap exists with the old `0.8.1` probing-fix family

## Sendable attachment

- `fuzz/repros/rkyv_swisstable_only_bundle_20260512.zip`

## Files to attach or reference in public follow-up

### For David email reply

- attach the zip above
- use `maintainer email reply template` from inside the bundle

### For `#667`

- `templates/comment_issue_667.md`
- `artifacts/original/issue01_empty_table.crash`
- `logs/standalone_issue01_empty_table.log`

### For `#664`

- `templates/comment_issue_664.md`
- `artifacts/minimized/issue02_hmap_overflow.min`
- `logs/version_replay_0.8.8_hmap.log`

### Optional supplement for `#665`

- `templates/comment_issue_665_optional.md`
- `patches/01_swisstable_verify_invariants.patch`

### For standalone `Issue 05`

- `templates/new_issue_05_probe_cycle.md`
- `templates/issue05_public_attachment_list.md`
- `artifacts/minimized/issue05_probe_cycle.min`
- `logs/issue05_final_helper_20260512.log`
- `logs/issue05_final_direct_compare_20260512.log`
- `logs/issue05_final_trace_20260512.log`
- `logs/issue05_final_patched_minimized_20260512.log`
- `docs/ISSUE_05_FINAL_STATUS.md`
- `docs/ISSUE_05_RERUN_SUMMARY.md`
- `docs/ISSUE_05_ROOT_CAUSE.md`

## Novelty outcome

At this point:

- `Issue 01` is still a duplicate
- `Issue 02` is still an overlapping duplicate
- `Issue 05` is now strong enough to file as a standalone public issue
  candidate
- the right framing for `Issue 05` is a safe-path non-terminating lookup
  candidate on `0.8.16`, likely in the same historical SwissTable probing
  family, i.e. a regression / reappearance / incomplete-fix candidate rather
  than a wholly novel bug class
