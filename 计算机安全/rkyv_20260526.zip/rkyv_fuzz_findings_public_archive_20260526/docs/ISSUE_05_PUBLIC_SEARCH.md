# Issue 05 public-search note

## Current tracker check

The current `rkyv` public SwissTable issues checked during this triage pass are:

- `#664`: heap-buffer-overflow in `ArchivedHashTable::control_raw`
- `#665`: out-of-bounds read via crafted bucket offset
- `#667`: reachable `control_raw` assertion via crafted `HashMap`

None of those current issues describe the same failure class as `Issue 05`.
`Issue 05` is a safe-path non-terminating lookup / traversal candidate rather
than an immediate assertion or out-of-bounds read.

## Historical overlap

There is historical public overlap with the `0.8.1` release note stating that
that release corrected an infinite loop in hash map probing:

- https://github.com/rkyv/rkyv/releases/tag/0.8.1

That historical note is the reason the public framing for `Issue 05` should be:

- regression candidate
- reappearance candidate
- incomplete-fix candidate

rather than a wholly novel bug class.

## Conclusion

The current tracker does not show a clear duplicate for the specific `0.8.16`
safe-path non-termination candidate confirmed in this bundle. The right public
position is therefore:

- separate public issue candidate
- conservative wording
- explicit historical-overlap note with the old probing-fix family
