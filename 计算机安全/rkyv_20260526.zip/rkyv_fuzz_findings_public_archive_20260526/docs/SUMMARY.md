# Summary of findings

## Project objective

The fuzzing campaign tested whether malformed archived bytes could pass checked
or safe `rkyv` access and then fail during later container traversal. The focus
was not raw crash count; the focus was reproducible evidence, checked-path
reachability, root-cause plausibility, patch validation, and public tracker
triage.

## Finding summary

### Issue 01: SwissTable empty-table invariant

- Component: `ArchivedHashTable` / SwissTable.
- Core condition: `len == 0 && cap > 0`.
- Failure family: safe path reaches `control_raw` / empty-table invariant
  assertion behavior.
- Public status: duplicate/overlap comment on `#667`.
- Verifier-side idea: reject invalid empty table state by enforcing
  `len == 0 => cap == 0`.

### Issue 02: SwissTable `FULL` bucket count mismatch

- Component: `ArchivedHashTable` / SwissTable.
- Core condition: counted `FULL` buckets do not match archived table header
  `len`.
- Failure family: malformed table shape can reach later crash behavior.
- Public status: overlap comment on `#664`; `#665` is adjacent context only.
- Verifier-side idea: reject malformed archived table shapes earlier by
  checking logical consistency between control bytes and header length.

### Issue 03: B-tree invalid required child pointer

- Component: `ArchivedBTreeMap`.
- Core condition: reachable inner-node child edge insufficiently validated.
- Failure family: later iterator traversal can follow an invalid child
  relationship.
- Public status: retained as overlap context after upstream B-tree reports and
  fixes.

### Issue 04: B-tree entry-count / empty-leaf inconsistency

- Component: `ArchivedBTreeMap`.
- Core condition: non-empty map can contain an empty leaf, or actual traversable
  entry count can disagree with header `len`.
- Public status: retained as overlap context after public B-tree entry-count
  work.

### Issue 05: SwissTable non-terminating lookup / traversal

- Component: `ArchivedHashMap` / SwissTable probing.
- Core condition: checked access succeeds before later `HashMap` traversal or
  lookup does not terminate.
- Evidence: `5/5` self-contained timeouts, `10/10` direct timeouts, `60s`
  timeout, checked-path trace, patched rerun returns normally.
- Public status: opened separately as GitHub `#668`.
- Framing: confirmed non-termination / DoS via crafted input; possible
  regression or incomplete-fix candidate in the historical SwissTable probing
  family; not a memory-safety claim.

## What this archive is not

This is not the original private email bundle. It intentionally avoids private
email content and instead preserves public-friendly technical evidence and
tracker text.
