# Issue 05 final classification

- baseline_commit: 4a841456f348b9c8115ba4d9fda70332af3d69c5
- version_line: rkyv 0.8.16
- helper_timeout_ratio: 5/5
- minimized_timeout20_ratio: 10/10, timeout60=yes
- original_timeout20_ratio: 10/10, timeout60=yes
- selected_seed: minimized
- selected_timeout20_ratio: 10/10, timeout60=yes
- checked_access_before_hang: yes
- patched_timeout_ratio: 0/5
- final_classification: strong_stable_candidate
