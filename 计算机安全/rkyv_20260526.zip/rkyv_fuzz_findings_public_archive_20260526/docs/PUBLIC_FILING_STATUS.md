# Public filing status

## GitHub `#667`

Action: duplicate/overlap comment.

The comment states that the local repro overlaps the SwissTable /
`ArchivedHashTable` verifier family already discussed in `#667`. The extra
technical contribution is the verifier-side empty-table rule: `len == 0` should
imply `cap == 0`. The comment avoids opening a duplicate issue.

File: `github/comment_issue_667.md`

## GitHub `#664`

Action: overlap comment.

The comment states that the local repro belongs to the same malformed
SwissTable / `ArchivedHashTable` family. It distinguishes the likely direct
low-level SIMD/control-byte boundary fix from the local verifier-side patch
sketch, which rejects a subset of malformed table shapes earlier by comparing
counted `FULL` buckets with the archived header `len`.

File: `github/comment_issue_664.md`

## GitHub `#665`

Action: optional only.

This is adjacent backing-pointer containment context, not a separate local
claim. It should only be posted if the discussion asks for that hardening angle.

File: `github/comment_issue_665_optional.md`

## GitHub `#668`

Action: new public issue.

Issue 05 was filed separately because no clear current duplicate was found for
safe-path SwissTable non-termination on `0.8.16`. The public issue text includes
the self-contained reproducer, minimized seed, final logs, checked-path trace,
patched behavior, and historical-overlap note.

File: `github/new_issue_668_issue05_probe_cycle.md`

## Maintainer email bundle

The maintainer requested a SwissTable-only bundle after confirming B-tree
overlap. This public archive includes the SwissTable-only bundle contents that
are suitable for preservation, but omits private email screenshots/templates.
