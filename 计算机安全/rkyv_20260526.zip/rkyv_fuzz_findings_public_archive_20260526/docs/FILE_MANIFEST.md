# File manifest

## Docs

- `docs/SUMMARY.md`: high-level overview of all five issue families.
- `docs/PUBLIC_FILING_STATUS.md`: final public tracker handling.
- `docs/HARNESS_AND_REPLAY.md`: harness and replay guide.
- `docs/ISSUE_*.md`: detailed issue notes copied or updated from the working
  bundles.
- `docs/PATCH_COVERAGE.md`: mapping from patch pieces to issue coverage.

## GitHub text

- `github/comment_issue_667.md`: public duplicate comment for Issue 01.
- `github/comment_issue_664.md`: public overlap comment for Issue 02.
- `github/comment_issue_665_optional.md`: optional adjacent context.
- `github/new_issue_668_issue05_probe_cycle.md`: public Issue 05 body.
- `github/issue05_public_attachment_list.md`: recommended Issue 05 attachment
  list.

## Artifacts

- `artifacts/original/`: representative original crash/timeout inputs.
- `artifacts/minimized/`: minimized or reduced inputs, including the final
  Issue 05 seed.

## Code and patches

- `harnesses/`: fuzz targets.
- `reproducers/`: standalone replay sources.
- `scripts/`: helper scripts.
- `patches/`: patch sketches and historical combined patch.

## Reports

- `reports/report_en.pdf` and `reports/report_zh.pdf`: final course reports.
- `reports/report_en.tex` and `reports/report_zh.tex`: corresponding LaTeX
  sources.
EOF
