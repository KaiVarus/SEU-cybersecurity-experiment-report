# Issue 04: related B-tree structural-count / empty-leaf note

## Summary

This note is included for context because the fuzzing work hit a B-tree family
where checked access could admit malformed archived shapes in which:

- a non-empty tree contained an empty leaf node, or
- the actual traversable entry count did not match the header `len`

That let iterators trust a corrupted structure and later underflow or walk into
bad values.

## Public overlap caveat

This note is **not** the strongest candidate for a new confidential claim at
this point.

Current upstream `origin/main` already contains public B-tree work in this
area:

- public issue `#590`: `ArchivedBTreeMap's .iter() does not iterate over all
  items when .len() > 65`
- current upstream commit `4a841456f348b9c8115ba4d9fda70332af3d69c5`:
  `Fix B-Tree maps not validating number of entries`

Because of that overlap, this note is better presented as related verifier
context and crash evidence, not as a fully separate new private discovery or
as part of the attached private patch claim.

## Original symptom

This family was discovered in the later post-patch long run after the earlier
SwissTable fixes landed.

Representative artifacts:

- `crash-b7c833ec658eafbb0bdb60c55c6bd086d683b5c0`
- `crash-08defd8a6e42be22bf0975017ef86d4fc05ef9e6`
- `crash-7a3b0803a526036324044d9ab5c90d4eaa5c7323`

Typical runtime blast radius:

- `btree/map/iter.rs:294`
- downstream `vec.rs:56` while iterating `payload.btree`

## Historical evidence in this bundle

- historical long-run logs:
  - `logs/post_patch_longrun_20260505_132858_fuzz_target_9_unsafe.log`
  - `logs/post_patch_longrun_20260505_132858_fuzz_target_10_unsafe.log`
- representative artifacts:
  - `artifacts/crashes/crash-b7c833ec658eafbb0bdb60c55c6bd086d683b5c0`
  - `artifacts/crashes/crash-08defd8a6e42be22bf0975017ef86d4fc05ef9e6`
  - `artifacts/crashes/crash-7a3b0803a526036324044d9ab5c90d4eaa5c7323`
- representative release-tag replay:
  - `logs/version_replay_0.8.8_btree.log`

## Fix direction

During verification:

- reject empty leaf nodes in a non-empty map
- recursively count all traversable entries
- reject the archive unless `actual == self.len()`

## Current verification status

On the local patched tree used for the original audit:

- the focused B-tree test suite passes
- the three representative post-patch-longrun artifacts now replay cleanly

On current upstream, the structural count side of this family should be read
as overlapping public work rather than as a standalone confidential report.
