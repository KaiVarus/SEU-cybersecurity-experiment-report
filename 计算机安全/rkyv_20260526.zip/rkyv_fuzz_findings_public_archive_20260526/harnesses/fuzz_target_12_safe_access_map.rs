#![no_main]

use std::collections::{BTreeMap, HashMap};

use libfuzzer_sys::fuzz_target;
use rkyv::{
    api::{self, high},
    from_bytes,
    rancor::Error,
    to_bytes,
    util::AlignedVec,
    Archive, Deserialize, Serialize,
};

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
struct MapPayload {
    btree: BTreeMap<i32, i32>,
    hmap: HashMap<u64, i32>,
    nested: BTreeMap<i32, Vec<u8>>,
    tag: String,
    nonce: u64,
}

fn take_u8(data: &[u8], idx: &mut usize) -> u8 {
    if data.is_empty() {
        return 0;
    }
    let b = data[*idx % data.len()];
    *idx = idx.wrapping_add(1);
    b
}

fn take_u32(data: &[u8], idx: &mut usize) -> u32 {
    let b0 = take_u8(data, idx) as u32;
    let b1 = take_u8(data, idx) as u32;
    let b2 = take_u8(data, idx) as u32;
    let b3 = take_u8(data, idx) as u32;
    b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
}

fn take_u64(data: &[u8], idx: &mut usize) -> u64 {
    let lo = take_u32(data, idx) as u64;
    let hi = take_u32(data, idx) as u64;
    lo | (hi << 32)
}

fn take_i32(data: &[u8], idx: &mut usize) -> i32 {
    take_u32(data, idx) as i32
}

fn make_ascii(data: &[u8], idx: &mut usize, max_len: usize) -> String {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = String::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        let b = take_u8(data, idx);
        out.push((b'a' + (b % 26)) as char);
        i += 1;
    }
    out
}

fn build_payload(data: &[u8]) -> MapPayload {
    let mut idx = 0usize;

    let mut btree = BTreeMap::new();
    let btree_len = (take_u8(data, &mut idx) as usize) % 64;
    for _ in 0..btree_len {
        btree.insert(take_i32(data, &mut idx), take_i32(data, &mut idx));
    }

    let mut hmap = HashMap::new();
    let hmap_len = (take_u8(data, &mut idx) as usize) % 64;
    for _ in 0..hmap_len {
        hmap.insert(take_u64(data, &mut idx), take_i32(data, &mut idx));
    }

    let mut nested = BTreeMap::new();
    let nested_len = (take_u8(data, &mut idx) as usize) % 24;
    for _ in 0..nested_len {
        let key = take_i32(data, &mut idx);
        let blob_len = (take_u8(data, &mut idx) as usize) % 64;
        let mut blob = Vec::with_capacity(blob_len);
        for _ in 0..blob_len {
            blob.push(take_u8(data, &mut idx));
        }
        nested.insert(key, blob);
    }

    MapPayload {
        btree,
        hmap,
        nested,
        tag: make_ascii(data, &mut idx, 48),
        nonce: take_u64(data, &mut idx),
    }
}

fn mutate_inplace(buf: &mut [u8], data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 64;
    for _ in 0..rounds {
        let op = take_u8(data, &mut idx) % 4;
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match op {
            0 => buf[p] ^= take_u8(data, &mut idx),
            1 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    let bytes = take_u32(data, &mut idx).to_le_bytes();
                    buf[p..p + 4].copy_from_slice(&bytes);
                }
            }
            2 => {
                let s = (take_u32(data, &mut idx) as usize) % buf.len();
                buf[p] = buf[s];
            }
            _ => {
                let e = (p + ((take_u8(data, &mut idx) as usize) % 24))
                    .min(buf.len());
                if e > p + 1 {
                    buf[p..e].rotate_left(1);
                }
            }
        }
    }
}

fn mutate_varlen(buf: &mut Vec<u8>, data: &[u8]) {
    if data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 48;
    for _ in 0..rounds {
        match take_u8(data, &mut idx) % 4 {
            0 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[p] ^= take_u8(data, &mut idx);
                }
            }
            1 => {
                if buf.len() < 32768 {
                    let p =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.insert(p, take_u8(data, &mut idx));
                }
            }
            2 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf.remove(p);
                }
            }
            _ => {
                if !buf.is_empty() {
                    let n =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.truncate(n);
                }
            }
        }
    }
}

fn touch_payload(p: &ArchivedMapPayload, salt: usize) {
    let _ = p.tag.len();
    let _ = p.nonce;
    let _ = p.btree.len();
    let _ = p.hmap.len();
    let _ = p.hmap.capacity();
    let _ = p.nested.len();

    let mut seen = 0usize;
    for (key, value) in p.btree.iter() {
        let _ = key;
        let _ = value;
        if ((seen ^ salt) & 3) == 0 {
            let _ = p.btree.get(key);
            let _ = p.btree.contains_key(key);
        }
        seen += 1;
        if seen > 512 {
            break;
        }
    }

    let mut hseen = 0usize;
    for (key, value) in p.hmap.iter() {
        let _ = key;
        let _ = value;
        if ((hseen ^ salt) & 1) == 0 {
            let _ = p.hmap.get(key);
            let _ = p.hmap.contains_key(key);
        }
        hseen += 1;
        if hseen > 512 {
            break;
        }
    }

    for key in p.hmap.keys().take(128) {
        let _ = p.hmap.get(key);
    }
    for value in p.hmap.values().take(128) {
        let _ = value;
    }

    for (key, blob) in p.nested.iter().take(128) {
        let _ = key;
        if let Some(first) = blob.first() {
            let _ = *first;
        }
    }
}

fn exercise(bytes: &[u8], salt: usize) {
    let mut aligned = AlignedVec::<16>::new();
    aligned.extend_from_slice(bytes);

    let root_pos = api::root_position::<ArchivedMapPayload>(aligned.len());
    if root_pos < aligned.len() {
        if let Ok(payload) =
            high::access_pos::<ArchivedMapPayload, Error>(&aligned, root_pos)
        {
            touch_payload(payload, salt);
        }
    }

    if aligned.len() <= 4096 || (salt & 0x0f) == 0 {
        let _ = from_bytes::<MapPayload, Error>(&aligned);
    }
}

fuzz_target!(|data: &[u8]| {
    exercise(data, 0);

    let payload = build_payload(data);
    if let Ok(bytes) = to_bytes::<Error>(&payload) {
        exercise(&bytes, 1);

        let mut mutated = bytes.to_vec();
        mutate_inplace(&mut mutated, data);
        exercise(&mutated, 2);

        mutate_varlen(&mut mutated, data);
        exercise(&mutated, 3);
    }
});
