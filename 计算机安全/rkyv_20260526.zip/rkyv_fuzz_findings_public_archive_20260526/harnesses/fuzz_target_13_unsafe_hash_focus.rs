#![no_main]

use std::collections::HashMap;

use libfuzzer_sys::fuzz_target;
use rkyv::{
    access, access_unchecked, access_unchecked_mut,
    api::{self, high, low},
    from_bytes, from_bytes_unchecked,
    rancor::Error,
    util::AlignedVec,
    Archive, Deserialize, Serialize,
};

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
struct HashFocusPayload {
    ids: HashMap<u64, u64>,
    blobs: HashMap<u64, Vec<u8>>,
    texts: HashMap<String, Vec<u8>>,
    nested: Vec<HashMap<u64, u32>>,
    tag: String,
    nonce: u64,
}

fn take_u8(data: &[u8], idx: &mut usize) -> u8 {
    if data.is_empty() {
        return 0;
    }
    let b = data[*idx % data.len()];
    *idx = idx.wrapping_add(1);
    b
}

fn take_u32(data: &[u8], idx: &mut usize) -> u32 {
    let b0 = take_u8(data, idx) as u32;
    let b1 = take_u8(data, idx) as u32;
    let b2 = take_u8(data, idx) as u32;
    let b3 = take_u8(data, idx) as u32;
    b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
}

fn take_u64(data: &[u8], idx: &mut usize) -> u64 {
    let lo = take_u32(data, idx) as u64;
    let hi = take_u32(data, idx) as u64;
    lo | (hi << 32)
}

fn make_ascii(data: &[u8], idx: &mut usize, max_len: usize) -> String {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = String::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.push((b'a' + (take_u8(data, idx) % 26)) as char);
        i += 1;
    }
    out
}

fn make_bytes(data: &[u8], idx: &mut usize, max_len: usize) -> Vec<u8> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = Vec::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.push(take_u8(data, idx));
        i += 1;
    }
    out
}

fn build_map_u64_u64(
    data: &[u8],
    idx: &mut usize,
    max_len: usize,
) -> HashMap<u64, u64> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = HashMap::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.insert(take_u64(data, idx), take_u64(data, idx));
        i += 1;
    }
    out
}

fn build_map_u64_u32(
    data: &[u8],
    idx: &mut usize,
    max_len: usize,
) -> HashMap<u64, u32> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = HashMap::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.insert(take_u64(data, idx), take_u32(data, idx));
        i += 1;
    }
    out
}

fn build_map_u64_blob(
    data: &[u8],
    idx: &mut usize,
    max_len: usize,
    blob_len: usize,
) -> HashMap<u64, Vec<u8>> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = HashMap::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.insert(take_u64(data, idx), make_bytes(data, idx, blob_len));
        i += 1;
    }
    out
}

fn build_map_text_blob(
    data: &[u8],
    idx: &mut usize,
    max_len: usize,
    blob_len: usize,
) -> HashMap<String, Vec<u8>> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = HashMap::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.insert(make_ascii(data, idx, 32), make_bytes(data, idx, blob_len));
        i += 1;
    }
    out
}

fn build_payload(data: &[u8]) -> HashFocusPayload {
    let mut idx = 0usize;

    let ids = build_map_u64_u64(data, &mut idx, 96);
    let blobs = build_map_u64_blob(data, &mut idx, 72, 192);
    let texts = build_map_text_blob(data, &mut idx, 72, 128);

    let nested_len = (take_u8(data, &mut idx) as usize) % 8;
    let mut nested = Vec::with_capacity(nested_len);
    let mut i = 0usize;
    while i < nested_len {
        nested.push(build_map_u64_u32(data, &mut idx, 24));
        i += 1;
    }

    HashFocusPayload {
        ids,
        blobs,
        texts,
        nested,
        tag: make_ascii(data, &mut idx, 64),
        nonce: take_u64(data, &mut idx),
    }
}

fn mutate_inplace(buf: &mut [u8], data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 96;
    let mut i = 0usize;
    while i < rounds {
        let op = take_u8(data, &mut idx) % 5;
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match op {
            0 => buf[p] ^= take_u8(data, &mut idx),
            1 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    buf[p..p + 4]
                        .copy_from_slice(&take_u32(data, &mut idx).to_le_bytes());
                }
            }
            2 => {
                if buf.len() >= 8 && p <= buf.len() - 8 {
                    buf[p..p + 8]
                        .copy_from_slice(&take_u64(data, &mut idx).to_le_bytes());
                }
            }
            3 => {
                let src = (take_u32(data, &mut idx) as usize) % buf.len();
                buf[p] = buf[src];
            }
            _ => {
                let e = (p + ((take_u8(data, &mut idx) as usize) % 24))
                    .min(buf.len());
                if e > p + 1 {
                    buf[p..e].rotate_left(1);
                }
            }
        }
        i += 1;
    }
}

fn mutate_varlen(buf: &mut Vec<u8>, data: &[u8]) {
    if data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 72;
    let mut i = 0usize;
    while i < rounds {
        match take_u8(data, &mut idx) % 6 {
            0 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[p] ^= take_u8(data, &mut idx);
                }
            }
            1 => {
                if buf.len() < 32768 {
                    let p =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.insert(p, take_u8(data, &mut idx));
                }
            }
            2 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf.remove(p);
                }
            }
            3 => {
                if !buf.is_empty() {
                    let new_len =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.truncate(new_len);
                }
            }
            4 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    let e = (p + ((take_u8(data, &mut idx) as usize) % 32))
                        .min(buf.len());
                    if e > p + 1 {
                        buf[p..e].rotate_right(1);
                    }
                }
            }
            _ => {
                if !buf.is_empty() {
                    let src = (take_u32(data, &mut idx) as usize) % buf.len();
                    let dst = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[dst] = buf[src];
                }
            }
        }
        i += 1;
    }
}

fn smash_words(buf: &mut Vec<u8>, data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }

    let words32 = [
        0u32,
        1,
        2,
        4,
        8,
        16,
        32,
        0x8080_8080,
        0xfefe_fefe,
        0xffff_ffff,
    ];
    let words64 = [
        0u64,
        1,
        2,
        4,
        8,
        16,
        32,
        0x8080_8080_8080_8080,
        0xfefe_fefe_fefe_fefe,
        buf.len() as u64,
        api::root_position::<ArchivedHashFocusPayload>(buf.len()) as u64,
        u64::MAX,
    ];

    let mut idx = 0usize;
    let rounds = 8 + ((take_u8(data, &mut idx) as usize) % 56);
    let mut i = 0usize;
    while i < rounds {
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match take_u8(data, &mut idx) % 6 {
            0 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    let v = words32
                        [(take_u8(data, &mut idx) as usize) % words32.len()];
                    buf[p..p + 4].copy_from_slice(&v.to_le_bytes());
                }
            }
            1 => {
                if buf.len() >= 8 && p <= buf.len() - 8 {
                    let v = words64
                        [(take_u8(data, &mut idx) as usize) % words64.len()];
                    buf[p..p + 8].copy_from_slice(&v.to_le_bytes());
                }
            }
            2 => {
                let fill = match take_u8(data, &mut idx) % 3 {
                    0 => 0x00,
                    1 => 0x80,
                    _ => 0xff,
                };
                let e = (p + 4 + ((take_u8(data, &mut idx) as usize) % 20))
                    .min(buf.len());
                buf[p..e].fill(fill);
            }
            3 => {
                if buf.len() >= 16 {
                    let q = (p & !0xf).min(buf.len() - 16);
                    let fill = match take_u8(data, &mut idx) % 3 {
                        0 => 0x00,
                        1 => 0x80,
                        _ => 0xfe,
                    };
                    buf[q..q + 16].fill(fill);
                }
            }
            4 => {
                if !buf.is_empty() {
                    let src = (take_u32(data, &mut idx) as usize) % buf.len();
                    let width = 1 + ((take_u8(data, &mut idx) as usize) % 8);
                    if src + width <= buf.len() && p + width <= buf.len() {
                        let tmp = buf[src..src + width].to_vec();
                        buf[p..p + width].copy_from_slice(&tmp);
                    }
                }
            }
            _ => {
                if buf.len() >= 4 {
                    let q = (p & !3).min(buf.len() - 4);
                    let rel = buf.len().wrapping_sub(q) as u32;
                    buf[q..q + 4].copy_from_slice(&rel.to_le_bytes());
                }
            }
        }
        i += 1;
    }
}

fn touch_payload(p: &ArchivedHashFocusPayload, salt: usize) {
    let _ = p.tag.len();
    let _ = p.nonce;

    let _ = p.ids.len();
    let _ = p.ids.capacity();
    let mut seen = 0usize;
    for (key, value) in p.ids.iter() {
        let _ = key;
        let _ = value;
        if ((seen ^ salt) & 1) == 0 {
            let _ = p.ids.get(key);
            let _ = p.ids.contains_key(key);
        }
        seen += 1;
        if seen > 4096 {
            break;
        }
    }
    for key in p.ids.keys().take(256) {
        let _ = p.ids.get(key);
    }

    let _ = p.blobs.len();
    let _ = p.blobs.capacity();
    let mut bseen = 0usize;
    for (key, value) in p.blobs.iter() {
        let _ = key;
        let _ = value.len();
        if let Some(first) = value.first() {
            let _ = *first;
        }
        if ((bseen ^ salt) & 3) == 0 {
            let _ = p.blobs.get(key);
            let _ = p.blobs.contains_key(key);
        }
        bseen += 1;
        if bseen > 4096 {
            break;
        }
    }
    for value in p.blobs.values().take(128) {
        if let Some(first) = value.first() {
            let _ = *first;
        }
    }

    let _ = p.texts.len();
    let _ = p.texts.capacity();
    let mut tseen = 0usize;
    for (key, value) in p.texts.iter() {
        let s = key.as_str();
        let _ = s.len();
        if ((tseen ^ salt) & 1) == 0 {
            let _ = p.texts.contains_key(s);
            let _ = p.texts.get(s);
        }
        if let Some(first) = value.first() {
            let _ = *first;
        }
        tseen += 1;
        if tseen > 2048 {
            break;
        }
    }

    let _ = p.nested.len();
    for map in p.nested.iter().take(32) {
        let _ = map.len();
        let _ = map.capacity();
        for (key, value) in map.iter().take(128) {
            let _ = key;
            let _ = value;
            let _ = map.contains_key(key);
            let _ = map.get(key);
        }
    }
}

fn build_frame(archive: &[u8], data: &[u8]) -> (Vec<u8>, usize, usize) {
    if archive.is_empty() {
        return (Vec::new(), 0, 0);
    }

    let mut idx = 0usize;
    let prefix_len = (take_u8(data, &mut idx) as usize) % 24;
    let suffix_len = (take_u8(data, &mut idx) as usize) % 24;

    let mut framed =
        Vec::with_capacity(prefix_len + archive.len() + suffix_len);
    let mut i = 0usize;
    while i < prefix_len {
        framed.push(take_u8(data, &mut idx));
        i += 1;
    }
    framed.extend_from_slice(archive);
    let mut j = 0usize;
    while j < suffix_len {
        framed.push(take_u8(data, &mut idx));
        j += 1;
    }

    let root = prefix_len
        + api::root_position::<ArchivedHashFocusPayload>(archive.len());
    (framed, root, prefix_len)
}

fn run_rooted_paths(bytes: &[u8], salt: usize) {
    let mut aligned = AlignedVec::<16>::new();
    aligned.extend_from_slice(bytes);

    let root_pos = api::root_position::<ArchivedHashFocusPayload>(aligned.len());
    let mut valid = false;
    if root_pos < aligned.len() {
        if let Ok(payload) =
            high::access_pos::<ArchivedHashFocusPayload, Error>(&aligned, root_pos)
        {
            valid = true;
            touch_payload(payload, salt);
        }
    }

    if valid || ((salt & 0x1f) == 0 && aligned.len() <= 4096) {
        let _ = from_bytes::<HashFocusPayload, Error>(&aligned);
    }

    if valid {
        unsafe {
            let _ = from_bytes_unchecked::<HashFocusPayload, Error>(&aligned);
            let _ = low::from_bytes_unchecked::<HashFocusPayload, Error>(&aligned);

            let payload = api::access_pos_unchecked::<ArchivedHashFocusPayload>(
                &aligned, root_pos,
            );
            touch_payload(payload, salt ^ 0x55aa);

            let payload_root = access_unchecked::<ArchivedHashFocusPayload>(&aligned);
            touch_payload(payload_root, salt ^ 0xaa55);
        }

        let mut mutable = aligned.clone();
        if high::access_pos::<ArchivedHashFocusPayload, Error>(&mutable, root_pos)
            .is_ok()
        {
            unsafe {
                let payload = api::access_pos_unchecked_mut::<ArchivedHashFocusPayload>(
                    &mut mutable,
                    root_pos,
                );
                let _ = payload.ids.len();
                let _ = payload.blobs.len();
                let _ = payload.texts.len();
                let _ = payload.nested.len();

                let payload_root =
                    access_unchecked_mut::<ArchivedHashFocusPayload>(&mut mutable);
                let _ = payload_root.tag.len();
                let _ = payload_root.ids.capacity();
            }
        }
    }

    if aligned.len() > 1 {
        let off = salt % aligned.len();
        let sub = &aligned[off..];
        if let Ok(payload) = access::<ArchivedHashFocusPayload, Error>(sub) {
            touch_payload(payload, salt ^ off);
            unsafe {
                let _ = from_bytes_unchecked::<HashFocusPayload, Error>(sub);
                let _ = low::from_bytes_unchecked::<HashFocusPayload, Error>(sub);
            }
        }
    }
}

fn run_framed_once(frame: &[u8], root: usize, salt: usize) {
    if root >= frame.len() {
        return;
    }

    let mut valid = false;
    if let Ok(payload) =
        high::access_pos::<ArchivedHashFocusPayload, Error>(frame, root)
    {
        valid = true;
        touch_payload(payload, salt);
    }

    if valid {
        unsafe {
            let payload =
                api::access_pos_unchecked::<ArchivedHashFocusPayload>(frame, root);
            touch_payload(payload, salt ^ 0x9090);
        }

        let mut mutable = frame.to_vec();
        if high::access_pos::<ArchivedHashFocusPayload, Error>(&mutable, root)
            .is_ok()
        {
            unsafe {
                let payload = api::access_pos_unchecked_mut::<ArchivedHashFocusPayload>(
                    &mut mutable,
                    root,
                );
                let _ = payload.ids.len();
                let _ = payload.blobs.len();
                let _ = payload.texts.len();
            }
        }
    }
}

fn run_framed_paths(archive: &[u8], data: &[u8], salt: usize) {
    let (frame, root, prefix_len) = build_frame(archive, data);
    if frame.is_empty() {
        return;
    }

    run_framed_once(&frame, root, salt ^ 0x1010);

    let mut mutated = frame.clone();
    mutate_inplace(&mut mutated, data);
    run_framed_once(&mutated, root, salt ^ 0x2020);

    if prefix_len > 1 {
        let shift = prefix_len / 2;
        if root > shift {
            run_framed_once(&frame[shift..], root - shift, salt ^ 0x3030);
        }
    }
}

fuzz_target!(|data: &[u8]| {
    if data.is_empty() {
        return;
    }

    run_rooted_paths(data, data.len());

    let payload = build_payload(data);
    let clean = match rkyv::to_bytes::<Error>(&payload) {
        Ok(v) => v.into_vec(),
        Err(_) => return,
    };

    run_rooted_paths(&clean, clean.len() ^ 0x1111);
    run_framed_paths(&clean, data, clean.len() ^ 0x2222);

    let mut semi = clean.clone();
    mutate_inplace(&mut semi, data);
    run_rooted_paths(&semi, data[0] as usize ^ 0x3333);
    run_framed_paths(&semi, data, data[0] as usize ^ 0x4444);

    let mut mutated = clean;
    mutate_varlen(&mut mutated, data);
    run_rooted_paths(&mutated, data[0] as usize ^ 0x5555);
    run_framed_paths(&mutated, data, data[0] as usize ^ 0x6666);

    smash_words(&mut mutated, data);
    run_rooted_paths(&mutated, data[0] as usize ^ 0x7777);
    run_framed_paths(&mutated, data, data[0] as usize ^ 0x8888);
});
