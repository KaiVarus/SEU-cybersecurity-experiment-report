#![no_main]

use std::{
    collections::{BTreeMap, HashMap},
    rc::Rc,
    sync::Arc,
};

use libfuzzer_sys::fuzz_target;
use rkyv::{from_bytes, rancor::Error, Archive, Deserialize, Serialize};

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
struct SafeLeaf {
    id: u32,
    label: String,
    bytes: Vec<u8>,
    flags: [u8; 8],
}

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
enum SafeEvent {
    Empty,
    Text(String),
    Blob(Vec<u8>),
    Numbers(Vec<u16>),
    Pair(Result<String, Vec<u8>>),
}

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
struct SafeFrame {
    name: String,
    leaves: Vec<SafeLeaf>,
    btree: BTreeMap<i32, SafeLeaf>,
    hmap: HashMap<u64, Vec<u8>>,
    nested: Vec<Vec<u16>>,
    tags: Vec<String>,
    boxed: Box<[u8]>,
    rc_label: Rc<String>,
    arc_blob: Arc<Vec<u8>>,
    maybe: Option<SafeLeaf>,
    outcome: Result<Vec<u8>, String>,
    event: SafeEvent,
}

fn touch_leaf(leaf: &SafeLeaf) {
    let _ = leaf.id;
    let _ = leaf.label.len();
    let _ = leaf.bytes.len();
    let _ = leaf.flags[0];
}

fn touch_event(event: &SafeEvent) {
    match event {
        SafeEvent::Empty => {}
        SafeEvent::Text(s) => {
            let _ = s.len();
        }
        SafeEvent::Blob(v) => {
            let _ = v.len();
            if let Some(first) = v.first() {
                let _ = *first;
            }
        }
        SafeEvent::Numbers(v) => {
            let _ = v.len();
            if let Some(first) = v.first() {
                let _ = *first;
            }
        }
        SafeEvent::Pair(result) => match result {
            Ok(s) => {
                let _ = s.len();
            }
            Err(v) => {
                let _ = v.len();
            }
        },
    }
}

fn touch_frame(frame: &SafeFrame) {
    let _ = frame.name.len();

    for leaf in frame.leaves.iter().take(32) {
        touch_leaf(leaf);
    }

    for (key, leaf) in frame.btree.iter().take(32) {
        let _ = *key;
        touch_leaf(leaf);
    }

    for (key, blob) in frame.hmap.iter().take(32) {
        let _ = *key;
        let _ = blob.len();
    }

    for row in frame.nested.iter().take(32) {
        let _ = row.len();
    }

    for tag in frame.tags.iter().take(32) {
        let _ = tag.len();
    }

    let _ = frame.boxed.len();
    let _ = frame.rc_label.len();
    let _ = frame.arc_blob.len();

    if let Some(leaf) = frame.maybe.as_ref() {
        touch_leaf(leaf);
    }

    match &frame.outcome {
        Ok(bytes) => {
            let _ = bytes.len();
        }
        Err(text) => {
            let _ = text.len();
        }
    }

    touch_event(&frame.event);
}

fn exercise(bytes: &[u8]) {
    if let Ok(value) = from_bytes::<SafeLeaf, Error>(bytes) {
        touch_leaf(&value);
    }

    if let Ok(value) = from_bytes::<SafeEvent, Error>(bytes) {
        touch_event(&value);
    }

    if let Ok(value) = from_bytes::<SafeFrame, Error>(bytes) {
        touch_frame(&value);
    }
}

fn exercise_views(data: &[u8]) {
    exercise(data);

    if data.len() > 1 {
        exercise(&data[1..]);
    }

    if data.len() > 4 {
        exercise(&data[..data.len() / 2]);
        exercise(&data[data.len() / 3..]);
    }

    if data.len() > 8 {
        let third = data.len() / 3;
        let two_thirds = data.len() - third;
        exercise(&data[third..two_thirds]);
    }
}

fuzz_target!(|data: &[u8]| {
    exercise_views(data);
});
