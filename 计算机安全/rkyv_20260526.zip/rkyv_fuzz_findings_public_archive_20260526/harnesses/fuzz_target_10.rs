#![no_main]

use std::{
    collections::{BTreeMap, HashMap},
    rc::Rc,
    sync::Arc,
};

use libfuzzer_sys::fuzz_target;
use rkyv::{
    access, access_unchecked, access_unchecked_mut,
    api::{self, high},
    from_bytes, from_bytes_unchecked,
    rancor::Error,
    util::AlignedVec,
    with::{AsBox, Niche},
    Archive, Deserialize, Serialize,
};

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
pub enum LeafKind {
    Empty,
    Inline(String),
    Blob(Vec<u8>),
    Pair(Result<String, Vec<u8>>),
    Numbers(Vec<u32>),
}

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
pub struct Node {
    pub id: u32,
    pub name: String,
    pub data: Vec<u8>,
    pub tags: Vec<String>,
    pub opt_blob: Option<Box<[u8]>>,
    pub kind: LeafKind,
}

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
pub struct FramePayload {
    pub name: String,
    pub nodes: Vec<Node>,
    pub btree: BTreeMap<i32, Node>,
    pub hmap: HashMap<u64, Node>,
    pub nested_blobs: Vec<Box<[u8]>>,
    #[rkyv(with = AsBox)]
    pub boxed_node: Node,
    #[rkyv(with = Niche)]
    pub niched_ptr: Option<Box<u64>>,
    pub rc_label: Rc<String>,
    pub arc_blob: Arc<Vec<u8>>,
    pub maybe_node: Option<Node>,
    pub outcome: Result<Vec<u8>, String>,
    pub grid: Vec<Vec<u16>>,
}

fn take_u8(data: &[u8], idx: &mut usize) -> u8 {
    if data.is_empty() {
        return 0;
    }
    let byte = data[*idx % data.len()];
    *idx = idx.wrapping_add(1);
    byte
}

fn take_u16(data: &[u8], idx: &mut usize) -> u16 {
    let lo = take_u8(data, idx) as u16;
    let hi = take_u8(data, idx) as u16;
    lo | (hi << 8)
}

fn take_u32(data: &[u8], idx: &mut usize) -> u32 {
    let b0 = take_u8(data, idx) as u32;
    let b1 = take_u8(data, idx) as u32;
    let b2 = take_u8(data, idx) as u32;
    let b3 = take_u8(data, idx) as u32;
    b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
}

fn take_u64(data: &[u8], idx: &mut usize) -> u64 {
    let lo = take_u32(data, idx) as u64;
    let hi = take_u32(data, idx) as u64;
    lo | (hi << 32)
}

fn take_i32(data: &[u8], idx: &mut usize) -> i32 {
    take_u32(data, idx) as i32
}

fn make_ascii(data: &[u8], idx: &mut usize, max_len: usize) -> String {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = String::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.push((b'a' + (take_u8(data, idx) % 26)) as char);
        i += 1;
    }
    out
}

fn make_bytes(data: &[u8], idx: &mut usize, max_len: usize) -> Vec<u8> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = Vec::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.push(take_u8(data, idx));
        i += 1;
    }
    out
}

fn build_leaf_kind(data: &[u8], idx: &mut usize) -> LeafKind {
    match take_u8(data, idx) % 5 {
        0 => LeafKind::Empty,
        1 => LeafKind::Inline(make_ascii(data, idx, 48)),
        2 => LeafKind::Blob(make_bytes(data, idx, 256)),
        3 => {
            if (take_u8(data, idx) & 1) == 0 {
                LeafKind::Pair(Ok(make_ascii(data, idx, 64)))
            } else {
                LeafKind::Pair(Err(make_bytes(data, idx, 256)))
            }
        }
        _ => {
            let len = (take_u8(data, idx) as usize) % 32;
            let mut nums = Vec::with_capacity(len);
            let mut i = 0usize;
            while i < len {
                nums.push(take_u32(data, idx));
                i += 1;
            }
            LeafKind::Numbers(nums)
        }
    }
}

fn build_node(data: &[u8], idx: &mut usize) -> Node {
    let tag_count = (take_u8(data, idx) as usize) % 8;
    let mut tags = Vec::with_capacity(tag_count);
    let mut i = 0usize;
    while i < tag_count {
        tags.push(make_ascii(data, idx, 24));
        i += 1;
    }
    let opt_blob = if (take_u8(data, idx) & 1) == 0 {
        Some(make_bytes(data, idx, 192).into_boxed_slice())
    } else {
        None
    };
    Node {
        id: take_u32(data, idx),
        name: make_ascii(data, idx, 48),
        data: make_bytes(data, idx, 384),
        tags,
        opt_blob,
        kind: build_leaf_kind(data, idx),
    }
}

fn build_payload(data: &[u8]) -> FramePayload {
    let mut idx = 0usize;

    let node_count = (take_u8(data, &mut idx) as usize) % 10;
    let btree_count = (take_u8(data, &mut idx) as usize) % 24;
    let hmap_count = (take_u8(data, &mut idx) as usize) % 24;
    let blob_count = (take_u8(data, &mut idx) as usize) % 12;
    let row_count = (take_u8(data, &mut idx) as usize) % 10;

    let mut nodes = Vec::with_capacity(node_count);
    let mut i = 0usize;
    while i < node_count {
        nodes.push(build_node(data, &mut idx));
        i += 1;
    }

    let mut btree = BTreeMap::new();
    let mut j = 0usize;
    while j < btree_count {
        btree.insert(take_i32(data, &mut idx), build_node(data, &mut idx));
        j += 1;
    }

    let mut hmap = HashMap::new();
    let mut k = 0usize;
    while k < hmap_count {
        hmap.insert(take_u64(data, &mut idx), build_node(data, &mut idx));
        k += 1;
    }

    let mut nested_blobs = Vec::with_capacity(blob_count);
    let mut b = 0usize;
    while b < blob_count {
        nested_blobs.push(make_bytes(data, &mut idx, 224).into_boxed_slice());
        b += 1;
    }

    let mut grid = Vec::with_capacity(row_count);
    let mut r = 0usize;
    while r < row_count {
        let cols = (take_u8(data, &mut idx) as usize) % 24;
        let mut row = Vec::with_capacity(cols);
        let mut c = 0usize;
        while c < cols {
            row.push(take_u16(data, &mut idx));
            c += 1;
        }
        grid.push(row);
        r += 1;
    }

    let boxed_node = build_node(data, &mut idx);
    let maybe_node = if (take_u8(data, &mut idx) & 1) == 0 {
        Some(build_node(data, &mut idx))
    } else {
        None
    };
    let niched_ptr = if (take_u8(data, &mut idx) & 1) == 0 {
        Some(Box::new(take_u64(data, &mut idx)))
    } else {
        None
    };
    let outcome = if (take_u8(data, &mut idx) & 1) == 0 {
        Ok(make_bytes(data, &mut idx, 512))
    } else {
        Err(make_ascii(data, &mut idx, 80))
    };

    FramePayload {
        name: make_ascii(data, &mut idx, 64),
        nodes,
        btree,
        hmap,
        nested_blobs,
        boxed_node,
        niched_ptr,
        rc_label: Rc::new(make_ascii(data, &mut idx, 64)),
        arc_blob: Arc::new(make_bytes(data, &mut idx, 512)),
        maybe_node,
        outcome,
        grid,
    }
}

fn mutate_inplace(buf: &mut [u8], data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 96;
    let mut i = 0usize;
    while i < rounds {
        let op = take_u8(data, &mut idx) % 6;
        let pos = (take_u32(data, &mut idx) as usize) % buf.len();
        match op {
            0 => {
                buf[pos] ^= take_u8(data, &mut idx);
            }
            1 => {
                if buf.len() >= 4 && pos <= buf.len() - 4 {
                    let v = take_u32(data, &mut idx).to_le_bytes();
                    buf[pos..pos + 4].copy_from_slice(&v);
                }
            }
            2 => {
                if buf.len() >= 8 && pos <= buf.len() - 8 {
                    let v = take_u64(data, &mut idx).to_le_bytes();
                    buf[pos..pos + 8].copy_from_slice(&v);
                }
            }
            3 => {
                let src = (take_u32(data, &mut idx) as usize) % buf.len();
                buf[pos] = buf[src];
            }
            4 => {
                let end = (pos + ((take_u8(data, &mut idx) as usize) % 24))
                    .min(buf.len());
                if end > pos + 1 {
                    buf[pos..end].rotate_left(1);
                }
            }
            _ => {
                let end = (pos + ((take_u8(data, &mut idx) as usize) % 24))
                    .min(buf.len());
                if end > pos {
                    buf[pos..end].fill(0);
                }
            }
        }
        i += 1;
    }
}

fn mutate_varlen(buf: &mut Vec<u8>, data: &[u8]) {
    if data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 72;
    let mut i = 0usize;
    while i < rounds {
        let op = take_u8(data, &mut idx) % 6;
        match op {
            0 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[p] ^= take_u8(data, &mut idx);
                }
            }
            1 => {
                if buf.len() < 32768 {
                    let p =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.insert(p, take_u8(data, &mut idx));
                }
            }
            2 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf.remove(p);
                }
            }
            3 => {
                if !buf.is_empty() {
                    let new_len =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.truncate(new_len);
                }
            }
            4 => {
                if !buf.is_empty() {
                    let start = (take_u32(data, &mut idx) as usize) % buf.len();
                    let end = (start
                        + ((take_u8(data, &mut idx) as usize) % 32))
                        .min(buf.len());
                    if end > start + 1 {
                        buf[start..end].rotate_right(1);
                    }
                }
            }
            _ => {
                if !buf.is_empty() {
                    let src = (take_u32(data, &mut idx) as usize) % buf.len();
                    let dst = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[dst] = buf[src];
                }
            }
        }
        i += 1;
    }
}

fn smash_words(buf: &mut Vec<u8>, data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }

    let words32 = [
        0u32,
        1,
        2,
        4,
        8,
        16,
        32,
        0x7fff_ffff,
        0x8000_0000,
        0xffff_ffff,
    ];
    let words64 = [
        0u64,
        1,
        2,
        4,
        8,
        16,
        32,
        buf.len() as u64,
        api::root_position::<ArchivedFramePayload>(buf.len()) as u64,
        u32::MAX as u64,
        u64::MAX,
    ];

    let mut idx = 0usize;
    let rounds = 8 + ((take_u8(data, &mut idx) as usize) % 56);
    let mut i = 0usize;
    while i < rounds {
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match take_u8(data, &mut idx) % 5 {
            0 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    let v = words32
                        [(take_u8(data, &mut idx) as usize) % words32.len()];
                    buf[p..p + 4].copy_from_slice(&v.to_le_bytes());
                }
            }
            1 => {
                if buf.len() >= 8 && p <= buf.len() - 8 {
                    let v = words64
                        [(take_u8(data, &mut idx) as usize) % words64.len()];
                    buf[p..p + 8].copy_from_slice(&v.to_le_bytes());
                }
            }
            2 => {
                let end =
                    (p + 2 + ((take_u8(data, &mut idx) as usize) % 14))
                        .min(buf.len());
                if end > p {
                    buf[p..end].fill(0xff);
                }
            }
            3 => {
                if !buf.is_empty() {
                    let src = (take_u32(data, &mut idx) as usize) % buf.len();
                    let width = 1 + ((take_u8(data, &mut idx) as usize) % 8);
                    if src + width <= buf.len() && p + width <= buf.len() {
                        let tmp = buf[src..src + width].to_vec();
                        buf[p..p + width].copy_from_slice(&tmp);
                    }
                }
            }
            _ => {
                if buf.len() >= 4 {
                    let q = (p & !3).min(buf.len() - 4);
                    let rel = buf.len().wrapping_sub(q) as u32;
                    buf[q..q + 4].copy_from_slice(&rel.to_le_bytes());
                }
            }
        }
        i += 1;
    }
}

fn build_frame(archive: &[u8], data: &[u8]) -> (Vec<u8>, usize, usize) {
    if archive.is_empty() {
        return (Vec::new(), 0, 0);
    }

    let mut idx = 0usize;
    let prefix_len = (take_u8(data, &mut idx) as usize) % 24;
    let suffix_len = (take_u8(data, &mut idx) as usize) % 24;
    let mut framed =
        Vec::with_capacity(prefix_len + archive.len() + suffix_len);

    let mut p = 0usize;
    while p < prefix_len {
        framed.push(take_u8(data, &mut idx));
        p += 1;
    }
    framed.extend_from_slice(archive);
    let mut s = 0usize;
    while s < suffix_len {
        framed.push(take_u8(data, &mut idx));
        s += 1;
    }

    let root =
        prefix_len + api::root_position::<ArchivedFramePayload>(archive.len());
    (framed, root, prefix_len)
}

fn exhaust_leaf(kind: &ArchivedLeafKind) {
    match kind {
        ArchivedLeafKind::Empty => {}
        ArchivedLeafKind::Inline(s) => {
            let _ = &**s;
        }
        ArchivedLeafKind::Blob(v) => {
            let _ = v.len();
            if !v.is_empty() {
                let _ = v[0];
            }
        }
        ArchivedLeafKind::Pair(res) => match res {
            rkyv::result::ArchivedResult::Ok(s) => {
                let _ = &**s;
            }
            rkyv::result::ArchivedResult::Err(v) => {
                let _ = v.len();
                if !v.is_empty() {
                    let _ = v[0];
                }
            }
        },
        ArchivedLeafKind::Numbers(nums) => {
            let _ = nums.len();
            if !nums.is_empty() {
                let _ = nums[0];
            }
        }
    }
}

fn exhaust_node(node: &ArchivedNode) {
    let _ = node.id;
    let _ = &*node.name;
    let _ = node.data.len();
    if !node.data.is_empty() {
        let _ = node.data[0];
    }
    for tag in node.tags.iter() {
        let _ = &**tag;
    }
    if let Some(blob) = node.opt_blob.as_ref() {
        let _ = blob.len();
        if !blob.is_empty() {
            let _ = blob[0];
        }
    }
    exhaust_leaf(&node.kind);
}

fn exhaust_payload(payload: &ArchivedFramePayload, salt: usize) {
    let _ = &*payload.name;

    for node in payload.nodes.iter().take(64) {
        exhaust_node(node);
    }

    let mut seen = 0usize;
    for (k, v) in payload.btree.iter() {
        let _ = k;
        exhaust_node(v);
        if ((seen ^ salt) & 3) == 0 {
            let _ = payload.btree.get(k);
            let _ = payload.btree.contains_key(k);
        }
        seen += 1;
        if seen > 4096 {
            break;
        }
    }

    let mut ranged = 0usize;
    for (k, v) in payload.btree.range(..) {
        let _ = k;
        exhaust_node(v);
        ranged += 1;
        if ranged > 4096 {
            break;
        }
    }

    let mut hseen = 0usize;
    for (k, v) in payload.hmap.iter() {
        let _ = k;
        exhaust_node(v);
        if ((hseen ^ salt) & 1) == 0 {
            let _ = payload.hmap.get(k);
            let _ = payload.hmap.contains_key(k);
        }
        hseen += 1;
        if hseen > 4096 {
            break;
        }
    }

    for blob in payload.nested_blobs.iter().take(128) {
        let _ = blob.len();
        if !blob.is_empty() {
            let _ = blob[0];
        }
    }

    exhaust_node(&payload.boxed_node);

    if let Some(v) = payload.niched_ptr.as_ref() {
        let _ = **v;
    }

    let _ = &*payload.rc_label;
    let _ = payload.arc_blob.len();
    if !payload.arc_blob.is_empty() {
        let _ = payload.arc_blob[0];
    }

    if let Some(node) = payload.maybe_node.as_ref() {
        exhaust_node(node);
    }

    match &payload.outcome {
        rkyv::result::ArchivedResult::Ok(v) => {
            let _ = v.len();
            if !v.is_empty() {
                let _ = v[0];
            }
        }
        rkyv::result::ArchivedResult::Err(s) => {
            let _ = &**s;
        }
    }

    for row in payload.grid.iter().take(128) {
        let _ = row.len();
        if !row.is_empty() {
            let _ = row[0];
        }
    }
}

fn run_rooted_paths(bytes: &[u8], salt: usize) {
    let mut aligned: AlignedVec<16> = AlignedVec::new();
    aligned.extend_from_slice(bytes);

    let mut valid = false;
    if let Ok(payload) = access::<ArchivedFramePayload, Error>(&aligned) {
        valid = true;
        exhaust_payload(payload, salt);
    }

    if valid || ((salt & 0x3f) == 0 && aligned.len() <= 4096) {
        let _ = from_bytes::<FramePayload, Error>(&aligned);
    }

    if valid {
        unsafe {
            let _ = from_bytes_unchecked::<FramePayload, Error>(&aligned);
            let payload = access_unchecked::<ArchivedFramePayload>(&aligned);
            exhaust_payload(payload, salt ^ 0x55aa);
        }

        let mut mutable = aligned.clone();
        if access::<ArchivedFramePayload, Error>(&mutable).is_ok() {
            unsafe {
                let payload =
                    access_unchecked_mut::<ArchivedFramePayload>(&mut mutable);
                let _ = payload.name.len();
                let _ = payload.btree.len();
                let _ = payload.hmap.len();
                let _ = payload.nodes.len();
            }
        }
    }

    if aligned.len() > 1 {
        let off = salt % aligned.len();
        let sub = &aligned[off..];
        if let Ok(payload) = access::<ArchivedFramePayload, Error>(sub) {
            exhaust_payload(payload, salt ^ off);
            unsafe {
                let _ = from_bytes_unchecked::<FramePayload, Error>(sub);
            }
        }
    }
}

fn run_framed_once(frame: &[u8], root: usize, salt: usize) {
    if root >= frame.len() {
        return;
    }

    let mut valid = false;
    if let Ok(payload) =
        high::access_pos::<ArchivedFramePayload, Error>(frame, root)
    {
        valid = true;
        exhaust_payload(payload, salt);
    }

    if valid {
        unsafe {
            let payload =
                api::access_pos_unchecked::<ArchivedFramePayload>(frame, root);
            exhaust_payload(payload, salt ^ 0xaa55);
        }

        let mut mutable = frame.to_vec();
        if high::access_pos::<ArchivedFramePayload, Error>(&mutable, root)
            .is_ok()
        {
            unsafe {
                let payload = api::access_pos_unchecked_mut::<
                    ArchivedFramePayload,
                >(&mut mutable, root);
                let _ = payload.name.len();
                let _ = payload.btree.len();
                let _ = payload.hmap.len();
                let _ = payload.grid.len();
            }
        }
    }
}

fn run_framed_paths(archive: &[u8], data: &[u8], salt: usize) {
    let (frame, root, prefix_len) = build_frame(archive, data);
    if frame.is_empty() {
        return;
    }

    run_framed_once(&frame, root, salt ^ 0x1010);

    let mut mutated = frame.clone();
    mutate_inplace(&mut mutated, data);
    run_framed_once(&mutated, root, salt ^ 0x2020);

    if prefix_len > 1 {
        let shift = prefix_len / 2;
        if root > shift {
            let sub = &frame[shift..];
            run_framed_once(sub, root - shift, salt ^ 0x3030);
        }
    }
}

fuzz_target!(|data: &[u8]| {
    if data.is_empty() {
        return;
    }

    run_rooted_paths(data, data.len());

    let payload = build_payload(data);
    let clean = match rkyv::to_bytes::<Error>(&payload) {
        Ok(v) => v.into_vec(),
        Err(_) => return,
    };

    run_rooted_paths(&clean, clean.len() ^ 0x4444);
    run_framed_paths(&clean, data, data.len() ^ 0x8888);

    let mut semi = clean.clone();
    mutate_inplace(&mut semi, data);
    run_rooted_paths(&semi, data[0] as usize ^ 0x2222);
    run_framed_paths(&semi, data, data[0] as usize ^ 0x6666);

    let mut mutated = clean;
    mutate_varlen(&mut mutated, data);
    run_rooted_paths(&mutated, data[0] as usize ^ 0x9999);
    run_framed_paths(&mutated, data, data[0] as usize ^ 0xbbbb);

    smash_words(&mut mutated, data);
    run_rooted_paths(&mutated, data[0] as usize ^ 0xdddd);
    run_framed_paths(&mutated, data, data[0] as usize ^ 0xeeee);
});
