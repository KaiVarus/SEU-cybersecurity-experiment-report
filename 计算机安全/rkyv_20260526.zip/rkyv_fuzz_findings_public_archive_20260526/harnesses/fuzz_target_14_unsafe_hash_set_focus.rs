#![no_main]

use std::collections::HashSet;

use libfuzzer_sys::fuzz_target;
use rkyv::{
    access, access_unchecked, access_unchecked_mut,
    api::{self, high, low},
    from_bytes, from_bytes_unchecked,
    rancor::Error,
    util::AlignedVec,
    Archive, Deserialize, Serialize,
};

#[derive(Archive, Serialize, Deserialize, Debug, Clone)]
#[rkyv(derive(Debug))]
struct HashSetFocusPayload {
    ids: HashSet<u64>,
    small_ids: HashSet<u32>,
    texts: HashSet<String>,
    nested: Vec<HashSet<u64>>,
    shards: Vec<HashSet<String>>,
    tag: String,
    nonce: u64,
}

fn take_u8(data: &[u8], idx: &mut usize) -> u8 {
    if data.is_empty() {
        return 0;
    }
    let b = data[*idx % data.len()];
    *idx = idx.wrapping_add(1);
    b
}

fn take_u32(data: &[u8], idx: &mut usize) -> u32 {
    let b0 = take_u8(data, idx) as u32;
    let b1 = take_u8(data, idx) as u32;
    let b2 = take_u8(data, idx) as u32;
    let b3 = take_u8(data, idx) as u32;
    b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
}

fn take_u64(data: &[u8], idx: &mut usize) -> u64 {
    let lo = take_u32(data, idx) as u64;
    let hi = take_u32(data, idx) as u64;
    lo | (hi << 32)
}

fn make_ascii(data: &[u8], idx: &mut usize, max_len: usize) -> String {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = String::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        out.push((b'a' + (take_u8(data, idx) % 26)) as char);
        i += 1;
    }
    out
}

fn choose_u64_mask(data: &[u8], idx: &mut usize) -> u64 {
    match take_u8(data, idx) % 6 {
        0 => 0xff,
        1 => 0xffff,
        2 => 0x00ff_ffff,
        3 => 0xffff_ffff,
        4 => 0x0000_ffff_ffff_ffff,
        _ => u64::MAX,
    }
}

fn choose_u32_mask(data: &[u8], idx: &mut usize) -> u32 {
    match take_u8(data, idx) % 5 {
        0 => 0xff,
        1 => 0xffff,
        2 => 0x00ff_ffff,
        3 => 0x7fff_ffff,
        _ => u32::MAX,
    }
}

fn build_set_u64(data: &[u8], idx: &mut usize, max_len: usize) -> HashSet<u64> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mask = choose_u64_mask(data, idx);
    let mut out = HashSet::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        let raw = take_u64(data, idx);
        let v = if (take_u8(data, idx) & 1) == 0 {
            raw & mask
        } else {
            raw.rotate_left((take_u8(data, idx) % 63) as u32) & mask
        };
        out.insert(v);
        i += 1;
    }
    out
}

fn build_set_u32(data: &[u8], idx: &mut usize, max_len: usize) -> HashSet<u32> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mask = choose_u32_mask(data, idx);
    let mut out = HashSet::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        let raw = take_u32(data, idx);
        let v = if (take_u8(data, idx) & 1) == 0 {
            raw & mask
        } else {
            raw.rotate_left((take_u8(data, idx) % 31) as u32) & mask
        };
        out.insert(v);
        i += 1;
    }
    out
}

fn build_set_text(data: &[u8], idx: &mut usize, max_len: usize) -> HashSet<String> {
    let len = (take_u8(data, idx) as usize) % (max_len + 1);
    let mut out = HashSet::with_capacity(len);
    let mut i = 0usize;
    while i < len {
        let size = 1 + ((take_u8(data, idx) as usize) % 24);
        out.insert(make_ascii(data, idx, size));
        i += 1;
    }
    out
}

fn build_payload(data: &[u8]) -> HashSetFocusPayload {
    let mut idx = 0usize;
    let nested_len = (take_u8(data, &mut idx) as usize) % 8;
    let shards_len = (take_u8(data, &mut idx) as usize) % 8;

    let mut nested = Vec::with_capacity(nested_len);
    let mut i = 0usize;
    while i < nested_len {
        nested.push(build_set_u64(data, &mut idx, 40));
        i += 1;
    }

    let mut shards = Vec::with_capacity(shards_len);
    let mut j = 0usize;
    while j < shards_len {
        shards.push(build_set_text(data, &mut idx, 24));
        j += 1;
    }

    HashSetFocusPayload {
        ids: build_set_u64(data, &mut idx, 128),
        small_ids: build_set_u32(data, &mut idx, 160),
        texts: build_set_text(data, &mut idx, 128),
        nested,
        shards,
        tag: make_ascii(data, &mut idx, 64),
        nonce: take_u64(data, &mut idx),
    }
}

fn mutate_inplace(buf: &mut [u8], data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 96;
    let mut i = 0usize;
    while i < rounds {
        let op = take_u8(data, &mut idx) % 6;
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match op {
            0 => buf[p] ^= take_u8(data, &mut idx),
            1 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    buf[p..p + 4]
                        .copy_from_slice(&take_u32(data, &mut idx).to_le_bytes());
                }
            }
            2 => {
                if buf.len() >= 8 && p <= buf.len() - 8 {
                    buf[p..p + 8]
                        .copy_from_slice(&take_u64(data, &mut idx).to_le_bytes());
                }
            }
            3 => {
                let src = (take_u32(data, &mut idx) as usize) % buf.len();
                buf[p] = buf[src];
            }
            4 => {
                let e = (p + ((take_u8(data, &mut idx) as usize) % 24))
                    .min(buf.len());
                if e > p + 1 {
                    buf[p..e].rotate_left(1);
                }
            }
            _ => {
                let end = (p + 1 + ((take_u8(data, &mut idx) as usize) % 32))
                    .min(buf.len());
                buf[p..end].fill(match take_u8(data, &mut idx) % 6 {
                    0 => 0x00,
                    1 => 0x01,
                    2 => 0x7f,
                    3 => 0x80,
                    4 => 0xfe,
                    _ => 0xff,
                });
            }
        }
        i += 1;
    }
}

fn mutate_varlen(buf: &mut Vec<u8>, data: &[u8]) {
    if data.is_empty() {
        return;
    }
    let mut idx = 0usize;
    let rounds = (take_u8(data, &mut idx) as usize) % 72;
    let mut i = 0usize;
    while i < rounds {
        match take_u8(data, &mut idx) % 6 {
            0 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[p] ^= take_u8(data, &mut idx);
                }
            }
            1 => {
                if buf.len() < 32768 {
                    let p =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.insert(p, take_u8(data, &mut idx));
                }
            }
            2 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf.remove(p);
                }
            }
            3 => {
                if !buf.is_empty() {
                    let new_len =
                        (take_u32(data, &mut idx) as usize) % (buf.len() + 1);
                    buf.truncate(new_len);
                }
            }
            4 => {
                if !buf.is_empty() {
                    let p = (take_u32(data, &mut idx) as usize) % buf.len();
                    let e = (p + ((take_u8(data, &mut idx) as usize) % 32))
                        .min(buf.len());
                    if e > p + 1 {
                        buf[p..e].rotate_right(1);
                    }
                }
            }
            _ => {
                if !buf.is_empty() {
                    let src = (take_u32(data, &mut idx) as usize) % buf.len();
                    let dst = (take_u32(data, &mut idx) as usize) % buf.len();
                    buf[dst] = buf[src];
                }
            }
        }
        i += 1;
    }
}

fn smash_words(buf: &mut Vec<u8>, data: &[u8]) {
    if buf.is_empty() || data.is_empty() {
        return;
    }

    let words32 = [
        0u32,
        1,
        2,
        4,
        8,
        16,
        32,
        0x7f7f_7f7f,
        0x8080_8080,
        0xfefe_fefe,
        0xffff_ffff,
    ];
    let words64 = [
        0u64,
        1,
        2,
        4,
        8,
        16,
        32,
        buf.len() as u64,
        api::root_position::<ArchivedHashSetFocusPayload>(buf.len()) as u64,
        0x7f7f_7f7f_7f7f_7f7f,
        0x8080_8080_8080_8080,
        0xfefe_fefe_fefe_fefe,
        u64::MAX,
    ];
    let control = [0x00u8, 0x01, 0x7f, 0x80, 0xfe, 0xff];

    let mut idx = 0usize;
    let rounds = 8 + ((take_u8(data, &mut idx) as usize) % 56);
    let mut i = 0usize;
    while i < rounds {
        let p = (take_u32(data, &mut idx) as usize) % buf.len();
        match take_u8(data, &mut idx) % 5 {
            0 => {
                if buf.len() >= 4 && p <= buf.len() - 4 {
                    let v = words32
                        [(take_u8(data, &mut idx) as usize) % words32.len()];
                    buf[p..p + 4].copy_from_slice(&v.to_le_bytes());
                }
            }
            1 => {
                if buf.len() >= 8 && p <= buf.len() - 8 {
                    let v = words64
                        [(take_u8(data, &mut idx) as usize) % words64.len()];
                    buf[p..p + 8].copy_from_slice(&v.to_le_bytes());
                }
            }
            2 => {
                let end = (p + 2 + ((take_u8(data, &mut idx) as usize) % 18))
                    .min(buf.len());
                if end > p {
                    let fill = control
                        [(take_u8(data, &mut idx) as usize) % control.len()];
                    buf[p..end].fill(fill);
                }
            }
            3 => {
                let src = (take_u32(data, &mut idx) as usize) % buf.len();
                let width = 1 + ((take_u8(data, &mut idx) as usize) % 8);
                if src + width <= buf.len() && p + width <= buf.len() {
                    let tmp = buf[src..src + width].to_vec();
                    buf[p..p + width].copy_from_slice(&tmp);
                }
            }
            _ => {
                let end = (p + 4 + ((take_u8(data, &mut idx) as usize) % 20))
                    .min(buf.len());
                if end > p + 1 {
                    buf[p..end].rotate_left(1);
                }
            }
        }
        i += 1;
    }
}

fn touch_payload(p: &ArchivedHashSetFocusPayload, salt: usize) {
    let _ = p.tag.len();
    let _ = p.nonce;

    let _ = p.ids.len();
    let _ = p.ids.is_empty();
    for key in p.ids.iter().take(2048) {
        let _ = key;
        let _ = p.ids.contains(key);
        let _ = p.ids.get(key);
        if (salt & 1) == 0 {
            let _ = p.ids.contains(key);
        }
    }

    let _ = p.small_ids.len();
    for key in p.small_ids.iter().take(2048) {
        let _ = key;
        let _ = p.small_ids.contains(key);
        let _ = p.small_ids.get(key);
    }

    let _ = p.texts.len();
    for key in p.texts.iter().take(2048) {
        let s = key.as_str();
        let _ = s.len();
        let _ = p.texts.contains(s);
        let _ = p.texts.get(s);
    }

    for set in p.nested.iter().take(32) {
        let _ = set.len();
        let _ = set.is_empty();
        for key in set.iter().take(256) {
            let _ = key;
            let _ = set.contains(key);
            let _ = set.get(key);
        }
    }

    for set in p.shards.iter().take(32) {
        let _ = set.len();
        for key in set.iter().take(256) {
            let s = key.as_str();
            let _ = set.contains(s);
            let _ = set.get(s);
        }
    }
}

fn build_frame(archive: &[u8], data: &[u8]) -> (Vec<u8>, usize, usize) {
    if archive.is_empty() {
        return (Vec::new(), 0, 0);
    }

    let mut idx = 0usize;
    let prefix_len = (take_u8(data, &mut idx) as usize) % 24;
    let suffix_len = (take_u8(data, &mut idx) as usize) % 24;

    let mut framed =
        Vec::with_capacity(prefix_len + archive.len() + suffix_len);
    let mut i = 0usize;
    while i < prefix_len {
        framed.push(take_u8(data, &mut idx));
        i += 1;
    }
    framed.extend_from_slice(archive);
    let mut j = 0usize;
    while j < suffix_len {
        framed.push(take_u8(data, &mut idx));
        j += 1;
    }

    let root = prefix_len
        + api::root_position::<ArchivedHashSetFocusPayload>(archive.len());
    (framed, root, prefix_len)
}

fn run_rooted_paths(bytes: &[u8], salt: usize) {
    let mut aligned = AlignedVec::<16>::new();
    aligned.extend_from_slice(bytes);

    let root_pos = api::root_position::<ArchivedHashSetFocusPayload>(aligned.len());
    let mut valid = false;
    if root_pos < aligned.len() {
        if let Ok(payload) =
            high::access_pos::<ArchivedHashSetFocusPayload, Error>(&aligned, root_pos)
        {
            valid = true;
            touch_payload(payload, salt);
        }
    }

    if valid || ((salt & 0x1f) == 0 && aligned.len() <= 4096) {
        let _ = from_bytes::<HashSetFocusPayload, Error>(&aligned);
    }

    if valid {
        unsafe {
            let _ = from_bytes_unchecked::<HashSetFocusPayload, Error>(&aligned);
            let _ = low::from_bytes_unchecked::<HashSetFocusPayload, Error>(&aligned);

            let payload = api::access_pos_unchecked::<ArchivedHashSetFocusPayload>(
                &aligned, root_pos,
            );
            touch_payload(payload, salt ^ 0x55aa);

            let payload_root = access_unchecked::<ArchivedHashSetFocusPayload>(&aligned);
            touch_payload(payload_root, salt ^ 0xaa55);
        }

        let mut mutable = aligned.clone();
        if high::access_pos::<ArchivedHashSetFocusPayload, Error>(&mutable, root_pos)
            .is_ok()
        {
            unsafe {
                let payload = api::access_pos_unchecked_mut::<ArchivedHashSetFocusPayload>(
                    &mut mutable,
                    root_pos,
                );
                let _ = payload.ids.len();
                let _ = payload.small_ids.len();
                let _ = payload.texts.len();
                let _ = payload.nested.len();

                let payload_root =
                    access_unchecked_mut::<ArchivedHashSetFocusPayload>(&mut mutable);
                let _ = payload_root.tag.len();
                let _ = payload_root.shards.len();
            }
        }
    }

    if aligned.len() > 1 {
        let off = salt % aligned.len();
        let sub = &aligned[off..];
        if let Ok(payload) = access::<ArchivedHashSetFocusPayload, Error>(sub) {
            touch_payload(payload, salt ^ off);
            unsafe {
                let _ = from_bytes_unchecked::<HashSetFocusPayload, Error>(sub);
                let _ = low::from_bytes_unchecked::<HashSetFocusPayload, Error>(sub);
            }
        }
    }
}

fn run_framed_once(frame: &[u8], root: usize, salt: usize) {
    if root >= frame.len() {
        return;
    }

    let mut valid = false;
    if let Ok(payload) =
        high::access_pos::<ArchivedHashSetFocusPayload, Error>(frame, root)
    {
        valid = true;
        touch_payload(payload, salt);
    }

    if valid {
        unsafe {
            let payload =
                api::access_pos_unchecked::<ArchivedHashSetFocusPayload>(frame, root);
            touch_payload(payload, salt ^ 0x9090);
        }

        let mut mutable = frame.to_vec();
        if high::access_pos::<ArchivedHashSetFocusPayload, Error>(&mutable, root)
            .is_ok()
        {
            unsafe {
                let payload = api::access_pos_unchecked_mut::<ArchivedHashSetFocusPayload>(
                    &mut mutable,
                    root,
                );
                let _ = payload.ids.len();
                let _ = payload.small_ids.len();
                let _ = payload.texts.len();
            }
        }
    }
}

fn run_framed_paths(archive: &[u8], data: &[u8], salt: usize) {
    let (frame, root, prefix_len) = build_frame(archive, data);
    if frame.is_empty() {
        return;
    }

    run_framed_once(&frame, root, salt ^ 0x1010);

    let mut mutated = frame.clone();
    mutate_inplace(&mut mutated, data);
    run_framed_once(&mutated, root, salt ^ 0x2020);

    if prefix_len > 1 {
        let shift = prefix_len / 2;
        if root > shift {
            run_framed_once(&frame[shift..], root - shift, salt ^ 0x3030);
        }
    }
}

fuzz_target!(|data: &[u8]| {
    if data.is_empty() {
        return;
    }

    run_rooted_paths(data, data.len());

    let payload = build_payload(data);
    let clean = match rkyv::to_bytes::<Error>(&payload) {
        Ok(v) => v.into_vec(),
        Err(_) => return,
    };

    run_rooted_paths(&clean, clean.len() ^ 0x1111);
    run_framed_paths(&clean, data, clean.len() ^ 0x2222);

    let mut semi = clean.clone();
    mutate_inplace(&mut semi, data);
    run_rooted_paths(&semi, data[0] as usize ^ 0x3333);
    run_framed_paths(&semi, data, data[0] as usize ^ 0x4444);

    let mut mutated = clean;
    mutate_varlen(&mut mutated, data);
    run_rooted_paths(&mutated, data[0] as usize ^ 0x5555);
    run_framed_paths(&mutated, data, data[0] as usize ^ 0x6666);

    smash_words(&mut mutated, data);
    run_rooted_paths(&mutated, data[0] as usize ^ 0x7777);
    run_framed_paths(&mutated, data, data[0] as usize ^ 0x8888);
});
