#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ]; then
    echo "usage: $0 <target> <artifact> [timeout_sec]" >&2
    exit 1
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TARGET="$1"
ARTIFACT="$2"
TIMEOUT_SEC="${3:-10}"
BIN="$ROOT/target/x86_64-unknown-linux-gnu/release/$TARGET"
OUT_DIR="$ROOT/fuzz/repros/minimized"
STEM="$(basename "$ARTIFACT")"
LOG="$ROOT/fuzz_run_logs/timeout_analysis_${TARGET}_${STEM}.log"
MIN_OUT="$OUT_DIR/${STEM}.min"
ARTIFACT_ABS="$(readlink -f "$ARTIFACT")"

mkdir -p "$OUT_DIR" "$ROOT/fuzz_run_logs"

if [ ! -x "$BIN" ]; then
    echo "missing binary: $BIN" >&2
    exit 1
fi

if [ ! -f "$ARTIFACT" ]; then
    echo "missing artifact: $ARTIFACT" >&2
    exit 1
fi

{
    echo "# target=$TARGET"
    echo "# artifact=$ARTIFACT_ABS"
    echo "# timeout_sec=$TIMEOUT_SEC"
    echo
} > "$LOG"

repro=0
for attempt in 1 2 3; do
    echo "## replay attempt $attempt" >> "$LOG"
    if timeout "$((TIMEOUT_SEC + 5))"s "$BIN" "$ARTIFACT_ABS" -runs=1 -timeout="$TIMEOUT_SEC" -detect_leaks=0 >> "$LOG" 2>&1; then
        echo "attempt $attempt: completed" >> "$LOG"
    else
        status="$?"
        echo "attempt $attempt: exit=$status" >> "$LOG"
        if [ "$status" -eq 124 ] || [ "$status" -eq 70 ]; then
            repro="$((repro + 1))"
        fi
    fi
    echo >> "$LOG"
done

if [ "$repro" -eq 0 ]; then
    echo "classification=nonrepro_or_transient" >> "$LOG"
    echo "timeout did not reproduce consistently; skip minimization" >> "$LOG"
    echo "log: $LOG"
    exit 0
fi

if [ "$repro" -eq 1 ]; then
    echo "classification=flaky_timeout_candidate" >> "$LOG"
    echo "timeout reproduced once out of three attempts; skip minimization" >> "$LOG"
    echo "log: $LOG"
    exit 0
fi

echo "classification=reproducible_timeout" >> "$LOG"
echo "## tmin begin" >> "$LOG"

(
    cd "$ROOT/fuzz"
    cargo +nightly fuzz tmin "$TARGET" "$ARTIFACT_ABS" -- -timeout="$TIMEOUT_SEC" -exact_artifact_path="$MIN_OUT"
) >> "$LOG" 2>&1 || true

echo "log: $LOG"
if [ -f "$MIN_OUT" ]; then
    echo "minimized: $MIN_OUT"
fi
