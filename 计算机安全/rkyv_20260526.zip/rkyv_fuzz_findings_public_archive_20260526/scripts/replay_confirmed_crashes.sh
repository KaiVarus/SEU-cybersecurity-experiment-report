#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BIN_DIR="$ROOT/target/x86_64-unknown-linux-gnu/release"
LOG_DIR="$ROOT/fuzz/repros/logs"
SUMMARY="$LOG_DIR/summary.tsv"

mkdir -p "$LOG_DIR"

entries=(
  "target9_hmap_oob|fuzz_target_9|fuzz/artifacts/fuzz_target_9_unsafe/crash-e85e798ae1edacce08707d3486d3d4d6c630d4b9"
  "target9_table_assert|fuzz_target_9|fuzz/artifacts/fuzz_target_9_unsafe/crash-9217a13a36375558a8a7f4e6dce55c334efc1cd9"
  "target10_string_repr_oob|fuzz_target_10|fuzz/artifacts/fuzz_target_10_unsafe/crash-84c670c6d8c0ffdcf42b6136831a469b0f7e3071"
  "target10_vec_ub|fuzz_target_10|fuzz/artifacts/fuzz_target_10_unsafe/crash-9d9b177cb9c3dcbe025341f33a318005bb2b32e2"
  "target10_table_assert_a|fuzz_target_10|fuzz/artifacts/fuzz_target_10_unsafe/crash-7ee6b76cde99938b9ded635436592d9c1c3fa6c3"
  "target10_table_assert_b|fuzz_target_10|fuzz/artifacts/fuzz_target_10_unsafe/crash-9cd0bb4e6c4a9d07b1e034b0351a88a03a8c788b"
  "target10_table_assert_c|fuzz_target_10|fuzz/artifacts/fuzz_target_10_unsafe/crash-c6da4401fd511b09072e9ffe5a6cebb10531f7f1"
)

needles=("${@:-}")

matches_filter() {
  local id="$1"
  if [ "${#needles[@]}" -eq 0 ]; then
    return 0
  fi

  local needle
  for needle in "${needles[@]}"; do
    if [[ "$id" == *"$needle"* ]]; then
      return 0
    fi
  done
  return 1
}

root_cause_of() {
  local log="$1"
  if grep -q "Executed .* in .* ms" "$log"; then
    printf "%s" "mitigated_clean_replay"
  elif grep -q "rkyv/src/collections/swiss_table/map.rs:115" "$log"; then
    printf "%s" "swiss_table_map_oob"
  elif grep -q "rkyv/src/string/repr.rs:53" "$log"; then
    printf "%s" "string_repr_oob"
  elif grep -q "rkyv/src/vec.rs:56" "$log"; then
    printf "%s" "archived_vec_slice_ub"
  elif grep -q "rkyv/src/collections/swiss_table/table.rs:97" "$log"; then
    printf "%s" "swiss_table_empty_assert"
  elif grep -q "rkyv/src/collections/btree/map/iter.rs:294" "$log"; then
    printf "%s" "btree_iter_overflow"
  else
    printf "%s" "unclassified"
  fi
}

safe_path_of() {
  local log="$1"
  if grep -qE "fuzz_target_9\\.rs:(266|268)" "$log"; then
    printf "%s" "safe_access_pos"
  elif grep -qE "fuzz_target_10\\.rs:(520|522)" "$log"; then
    printf "%s" "safe_access"
  elif grep -qE "fuzz_target_10\\.rs:(566|568)" "$log"; then
    printf "%s" "safe_access_pos"
  else
    printf "%s" "not_proven_in_log"
  fi
}

status_of() {
  local log="$1"
  if grep -q "Executed .* in .* ms" "$log"; then
    printf "%s" "clean"
  elif grep -q "ERROR: AddressSanitizer" "$log"; then
    printf "%s" "asan"
  elif grep -q "unsafe precondition" "$log"; then
    printf "%s" "ub_precondition"
  elif grep -q "panicked at" "$log"; then
    printf "%s" "panic"
  else
    printf "%s" "unknown"
  fi
}

printf "id\ttarget\tstatus\troot_cause\tsafe_path\tartifact\tlog\n" > "$SUMMARY"

for entry in "${entries[@]}"; do
  IFS="|" read -r id target rel_artifact <<<"$entry"
  matches_filter "$id" || continue

  bin="$BIN_DIR/$target"
  artifact="$ROOT/$rel_artifact"
  log="$LOG_DIR/${id}.log"

  if [ ! -x "$bin" ]; then
    echo "missing binary: $bin" >&2
    echo "build with: cargo +nightly fuzz build $target" >&2
    exit 1
  fi

  if [ ! -f "$artifact" ]; then
    echo "missing artifact: $artifact" >&2
    exit 1
  fi

  {
    echo "# id=$id"
    echo "# target=$target"
    echo "# artifact=$artifact"
    echo "# command=RUST_BACKTRACE=1 ASAN_OPTIONS=detect_leaks=0:symbolize=1:abort_on_error=1 timeout 15s $bin $artifact -runs=1 -detect_leaks=0"
    echo
    RUST_BACKTRACE=1 \
    ASAN_OPTIONS="detect_leaks=0:symbolize=1:abort_on_error=1" \
      timeout 15s "$bin" "$artifact" -runs=1 -detect_leaks=0
  } >"$log" 2>&1 || true

  status="$(status_of "$log")"
  root_cause="$(root_cause_of "$log")"
  safe_path="$(safe_path_of "$log")"

  printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
    "$id" "$target" "$status" "$root_cause" "$safe_path" "$artifact" "$log" \
    >> "$SUMMARY"

  printf "%-28s %-15s %-24s %-18s %s\n" \
    "$id" "$status" "$root_cause" "$safe_path" "$log"
done

echo
echo "summary: $SUMMARY"
