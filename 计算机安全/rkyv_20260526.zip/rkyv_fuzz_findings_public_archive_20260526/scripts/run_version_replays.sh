#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 3 ]; then
  echo "usage: $0 <version-label> <binary> <log-prefix>" >&2
  exit 2
fi

VERSION="$1"
BIN="$2"
PREFIX="$3"
LOGDIR="<repo>/fuzz/repros/version_replay_logs"

mkdir -p "$LOGDIR"

cases=(
  "hmap|<repo>/fuzz/artifacts/fuzz_target_9_unsafe/crash-e85e798ae1edacce08707d3486d3d4d6c630d4b9"
  "btree|<repo>/fuzz/artifacts/post_patch_longrun_20260505_132858/fuzz_target_9_unsafe/crash-b7c833ec658eafbb0bdb60c55c6bd086d683b5c0"
  "timeout|<repo>/fuzz/artifacts/deep_post_commit_20260506_103407/fuzz_target_9_unsafe/timeout-939a87ad8b9cc5493a9c12cfef710c0b2f702b62"
)

for entry in "${cases[@]}"; do
  IFS="|" read -r name artifact <<<"$entry"
  log="$LOGDIR/${PREFIX}_${name}.log"
  {
    echo "# version=$VERSION"
    echo "# artifact=$artifact"
    echo "# command=$BIN $artifact -runs=1 -detect_leaks=0"
    echo
    RUST_BACKTRACE=1 \
    ASAN_OPTIONS="detect_leaks=0:symbolize=1:abort_on_error=1" \
      timeout 15s "$BIN" "$artifact" -runs=1 -detect_leaks=0
  } >"$log" 2>&1 || true

  echo "=== $VERSION $name ==="
  tail -n 20 "$log"
  echo
done
