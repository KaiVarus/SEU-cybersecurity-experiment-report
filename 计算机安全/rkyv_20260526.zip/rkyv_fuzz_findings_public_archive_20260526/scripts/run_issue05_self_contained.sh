#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -z "${REPO_ROOT:-}" ]; then
  echo "set REPO_ROOT=/path/to/rkyv-checkout" >&2
  exit 2
fi

cp "$BUNDLE_DIR/reproducers/issue05_self_contained_replay.rs" \
  "$REPO_ROOT/rkyv/examples/issue05_self_contained_replay.rs"

(
  cd "$REPO_ROOT"
  cargo build --offline -q -p rkyv --example issue05_self_contained_replay \
    --features bytecheck
  timeout "${ISSUE05_TIMEOUT:-20s}" \
    target/debug/examples/issue05_self_contained_replay
)
