#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BIN_DIR="$ROOT/target/x86_64-unknown-linux-gnu/release"

case_name="${1:-all}"

build_targets() {
  cargo +nightly fuzz build fuzz_target_9 >/dev/null
  cargo +nightly fuzz build fuzz_target_10 >/dev/null
}

run_case() {
  local name="$1"
  local target="$2"
  local artifact="$3"
  local expect="$4"

  local bin="$BIN_DIR/$target"
  local path="$ROOT/$artifact"

  echo "== $name =="
  echo "target : $target"
  echo "input  : $path"
  echo "expect : $expect"

  RUST_BACKTRACE=1 \
  ASAN_OPTIONS="detect_leaks=0:symbolize=1:abort_on_error=1" \
    timeout 15s "$bin" "$path" -runs=1 -detect_leaks=0 2>&1 || true

  echo
}

cd "$ROOT"
build_targets

case "$case_name" in
  empty-table|all)
    run_case \
      "empty-table-invariant" \
      "fuzz_target_9" \
      "fuzz/artifacts/fuzz_target_9_unsafe/crash-9217a13a36375558a8a7f4e6dce55c334efc1cd9" \
      "patched build: clean execution"
    ;&
  safe-map-oob|all)
    run_case \
      "safe-access-hmap-oob" \
      "fuzz_target_9" \
      "fuzz/artifacts/fuzz_target_9_unsafe/crash-e85e798ae1edacce08707d3486d3d4d6c630d4b9" \
      "patched build: clean execution"
    ;&
  string-oob|all)
    run_case \
      "safe-access-string-oob" \
      "fuzz_target_10" \
      "fuzz/artifacts/fuzz_target_10_unsafe/crash-84c670c6d8c0ffdcf42b6136831a469b0f7e3071" \
      "patched build: clean execution"
    ;&
  vec-ub|all)
    run_case \
      "safe-access-vec-ub" \
      "fuzz_target_10" \
      "fuzz/artifacts/fuzz_target_10_unsafe/crash-9d9b177cb9c3dcbe025341f33a318005bb2b32e2" \
      "patched build: clean execution"
    ;;
  *)
    echo "usage: $0 [all|empty-table|safe-map-oob|string-oob|vec-ub]" >&2
    exit 2
    ;;
esac
