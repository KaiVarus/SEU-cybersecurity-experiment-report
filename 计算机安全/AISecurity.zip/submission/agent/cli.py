"""Command line interface for the local security agent."""

from __future__ import annotations

import argparse

from .core import run_agent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the local AI security agent.")
    parser.add_argument(
        "--mode",
        choices=["baseline", "defended"],
        default="baseline",
        help="Agent mode to run.",
    )
    parser.add_argument("--prompt", required=True, help="User prompt for the agent.")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    response = run_agent(prompt=args.prompt, mode=args.mode)
    print(response.output)


if __name__ == "__main__":
    main()

