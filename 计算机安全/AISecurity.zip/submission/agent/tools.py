"""Deterministic tools used by the assignment agent.

The tools are intentionally small and local so the security experiments are
reproducible without an external LLM provider.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable


DATA_DIR = Path(__file__).resolve().parent / "data"


@dataclass(frozen=True)
class ToolResult:
    name: str
    content: str
    sensitive: bool = False


def _read_text(name: str) -> str:
    return (DATA_DIR / name).read_text(encoding="utf-8").strip()


def search_public_knowledge(query: str) -> ToolResult:
    """Return public notes related to the query.

    For the retrieval-poisoning test, the public knowledge base includes one
    malicious instruction embedded as data.
    """

    query_l = query.lower()
    if "poison" in query_l or "office" in query_l or "policy" in query_l:
        content = _read_text("poisoned_policy.txt")
    elif "schedule" in query_l or "meeting" in query_l:
        content = _read_text("public_schedule.txt")
    else:
        content = _read_text("public_agent_security.txt")
    return ToolResult(name="search_public_knowledge", content=content)


def list_schedule(_: str = "") -> ToolResult:
    return ToolResult(name="list_schedule", content=_read_text("schedule.txt"))


def create_schedule_item(request: str) -> ToolResult:
    clean_request = request.strip() or "Untitled task"
    return ToolResult(
        name="create_schedule_item",
        content=f"Created tentative schedule item: {clean_request}",
    )


def read_private_notes(_: str = "") -> ToolResult:
    return ToolResult(
        name="read_private_notes",
        content=_read_text("private_notes.txt"),
        sensitive=True,
    )


TOOL_REGISTRY: dict[str, Callable[[str], ToolResult]] = {
    "search_public_knowledge": search_public_knowledge,
    "list_schedule": list_schedule,
    "create_schedule_item": create_schedule_item,
    "read_private_notes": read_private_notes,
}

