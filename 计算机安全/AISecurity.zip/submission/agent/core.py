"""Baseline and defended local AI agent implementations."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum

from .tools import TOOL_REGISTRY, ToolResult


SENSITIVE_PATTERNS = [
    re.compile(r"PRIVATE_TOKEN=[A-Z0-9_\-]+"),
    re.compile(r"student_api_key_[a-z0-9_]+"),
    re.compile(r"Door code:\s*\d+"),
]

AUTH_TOKEN = "AUTH_TEST_456"

MALICIOUS_INPUT_PATTERNS = [
    "ignore previous",
    "ignore all previous",
    "bypass",
    "reveal",
    "leak",
    "private notes",
    "read_private_notes",
    "developer message",
    "system prompt",
    "hidden instruction",
]


class AgentMode(str, Enum):
    BASELINE = "baseline"
    DEFENDED = "defended"


@dataclass(frozen=True)
class AgentResponse:
    mode: AgentMode
    prompt: str
    selected_tools: tuple[str, ...]
    output: str
    blocked: bool = False


class LocalSecurityAgent:
    """A deterministic agent used for attack and defense experiments."""

    def __init__(self, mode: str | AgentMode = AgentMode.BASELINE):
        self.mode = AgentMode(mode)

    def run(self, prompt: str) -> AgentResponse:
        if self.mode is AgentMode.DEFENDED:
            return self._run_defended(prompt)
        return self._run_baseline(prompt)

    def _run_baseline(self, prompt: str) -> AgentResponse:
        selected_tools = self._baseline_plan(prompt)
        results = [self._call_tool(tool_name, prompt) for tool_name in selected_tools]
        output = self._compose_baseline_answer(prompt, results)
        return AgentResponse(
            mode=AgentMode.BASELINE,
            prompt=prompt,
            selected_tools=tuple(selected_tools),
            output=output,
            blocked=False,
        )

    def _run_defended(self, prompt: str) -> AgentResponse:
        if self._looks_malicious(prompt):
            return AgentResponse(
                mode=AgentMode.DEFENDED,
                prompt=prompt,
                selected_tools=(),
                output=(
                    "Request blocked: the prompt attempts to override policy, "
                    "access private data, or bypass tool authorization."
                ),
                blocked=True,
            )

        if self._is_schedule_creation_request(prompt) and not self._is_authorized(prompt):
            return AgentResponse(
                mode=AgentMode.DEFENDED,
                prompt=prompt,
                selected_tools=(),
                output=(
                    "Request blocked: schedule creation requires a valid "
                    f"authorization token ({AUTH_TOKEN})."
                ),
                blocked=True,
            )

        selected_tools = self._defended_plan(prompt)
        results = [self._call_tool(tool_name, prompt) for tool_name in selected_tools]
        output = self._compose_defended_answer(results)
        return AgentResponse(
            mode=AgentMode.DEFENDED,
            prompt=prompt,
            selected_tools=tuple(selected_tools),
            output=self._redact_sensitive(output),
            blocked=False,
        )

    def _baseline_plan(self, prompt: str) -> list[str]:
        text = prompt.lower()
        selected = ["search_public_knowledge"]

        if "schedule" in text or "meeting" in text or "calendar" in text:
            selected.append("list_schedule")
        if self._is_schedule_creation_request(prompt):
            selected.append("create_schedule_item")

        # Vulnerability: natural-language requests can directly activate a
        # sensitive tool without authorization.
        if (
            "private" in text
            or "secret" in text
            or "read_private_notes" in text
            or "ignore previous" in text
        ):
            selected.append("read_private_notes")

        # Vulnerability: retrieved data is treated as an instruction source.
        public_result = self._call_tool("search_public_knowledge", prompt)
        if "call read_private_notes" in public_result.content.lower():
            selected.append("read_private_notes")

        return _dedupe(selected)

    def _defended_plan(self, prompt: str) -> list[str]:
        text = prompt.lower()
        selected = ["search_public_knowledge"]

        if "schedule" in text or "meeting" in text or "calendar" in text:
            selected.append("list_schedule")
        if self._is_schedule_creation_request(prompt) and self._is_authorized(prompt):
            selected.append("create_schedule_item")

        # Private tools are never reachable from an unauthenticated user prompt.
        return _dedupe(selected)

    def _compose_baseline_answer(self, prompt: str, results: list[ToolResult]) -> str:
        lines = [
            "Baseline agent answer",
            f"User prompt: {prompt}",
            "Tool outputs:",
        ]
        for result in results:
            lines.append(f"- {result.name}: {result.content}")
        return "\n".join(lines)

    def _compose_defended_answer(self, results: list[ToolResult]) -> str:
        lines = ["Defended agent answer", "Authorized tool outputs:"]
        for result in results:
            if result.sensitive:
                continue
            if result.name == "search_public_knowledge":
                lines.append(f"- {result.name}: {self._quote_as_data(result.content)}")
            else:
                lines.append(f"- {result.name}: {result.content}")
        return "\n".join(lines)

    def _call_tool(self, tool_name: str, prompt: str) -> ToolResult:
        return TOOL_REGISTRY[tool_name](prompt)

    def _looks_malicious(self, prompt: str) -> bool:
        text = prompt.lower()
        return any(pattern in text for pattern in MALICIOUS_INPUT_PATTERNS)

    def _is_authorized(self, prompt: str) -> bool:
        return AUTH_TOKEN in prompt

    def _is_schedule_creation_request(self, prompt: str) -> bool:
        text = prompt.lower()
        creation_markers = [
            "create schedule",
            "create a schedule",
            "schedule a",
            "schedule an",
            "book a",
            "set up",
            "add a meeting",
        ]
        return any(marker in text for marker in creation_markers)

    def _quote_as_data(self, content: str) -> str:
        safe_lines = []
        for line in content.splitlines():
            line_l = line.lower()
            if "ignore previous" in line_l or "call read_private_notes" in line_l:
                safe_lines.append("[untrusted retrieved instruction removed]")
            else:
                safe_lines.append(line)
        return "\n  ".join(safe_lines)

    def _redact_sensitive(self, text: str) -> str:
        redacted = text
        for pattern in SENSITIVE_PATTERNS:
            redacted = pattern.sub("[REDACTED]", redacted)
        return redacted


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            output.append(item)
    return output


def run_agent(prompt: str, mode: str = "baseline") -> AgentResponse:
    return LocalSecurityAgent(mode=mode).run(prompt)
