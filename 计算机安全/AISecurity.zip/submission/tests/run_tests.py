"""Minimal dependency-free test runner for environments without pytest."""

from __future__ import annotations

import inspect
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import test_security_agent  # noqa: E402


def main() -> None:
    failures: list[tuple[str, BaseException]] = []
    tests = [
        (name, func)
        for name, func in inspect.getmembers(test_security_agent, inspect.isfunction)
        if name.startswith("test_")
    ]
    for name, func in tests:
        try:
            func()
            print(f"PASS {name}")
        except BaseException as exc:  # pragma: no cover - diagnostic runner
            failures.append((name, exc))
            print(f"FAIL {name}: {exc}")

    if failures:
        raise SystemExit(1)
    print(f"{len(tests)} tests passed")


if __name__ == "__main__":
    main()

